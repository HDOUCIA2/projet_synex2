<?php $__env->startSection('html-lang', 'fr'); ?>
<?php $__env->startSection('title', 'Créer un compte'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-4 mb-6">
  <div>
    <h4 class="mb-1">Créer un compte</h4>
    <p class="text-muted mb-0">Ajoutez un utilisateur à l’espace d’administration Synex.</p>
  </div>
</div>

<?php if(session('status')): ?>
  <div class="alert alert-success" role="status"><?php echo e(session('status')); ?></div>
<?php endif; ?>

<?php if($errors->any()): ?>
  <div class="alert alert-danger" role="alert">
    <ul class="mb-0">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

<div class="card">
  <div class="card-body">
    <form method="POST" action="<?php echo e(route('admin.users.store')); ?>">
      <?php echo csrf_field(); ?>
      <div class="row g-4">
        <div class="col-md-6">
          <label for="name" class="form-label">Nom complet</label>
          <input id="name" name="name" type="text" class="form-control" value="<?php echo e(old('name')); ?>" autocomplete="name" required>
        </div>
        <div class="col-md-6">
          <label for="username" class="form-label">Identifiant</label>
          <input id="username" name="username" type="text" class="form-control" value="<?php echo e(old('username')); ?>" autocomplete="username" required>
          <div class="form-text">3 à 30 caractères : lettres, chiffres, tirets ou soulignés.</div>
        </div>
        <div class="col-md-6">
          <label for="email" class="form-label">Adresse e-mail</label>
          <input id="email" name="email" type="email" class="form-control" value="<?php echo e(old('email')); ?>" autocomplete="email" required>
        </div>
        <div class="col-md-6">
          <label for="role" class="form-label">Type de compte</label>
          <select id="role" name="role" class="form-select" required>
            <option value="user" <?php if(old('role', 'user') === 'user'): echo 'selected'; endif; ?>>Utilisateur simple</option>
            <option value="admin" <?php if(old('role') === 'admin'): echo 'selected'; endif; ?>>Administrateur</option>
          </select>
        </div>
        <div class="col-md-6">
          <label for="password" class="form-label">Mot de passe</label>
          <input id="password" name="password" type="password" class="form-control" autocomplete="new-password" minlength="12" required>
          <div class="form-text">12 caractères minimum.</div>
        </div>
        <div class="col-md-6">
          <label for="password_confirmation" class="form-label">Confirmer le mot de passe</label>
          <input id="password_confirmation" name="password_confirmation" type="password" class="form-control" autocomplete="new-password" minlength="12" required>
        </div>
        <div class="col-12">
          <button type="submit" class="btn btn-primary">Créer le compte</button>
        </div>
      </div>
    </form>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/content/admin/users-create.blade.php ENDPATH**/ ?>