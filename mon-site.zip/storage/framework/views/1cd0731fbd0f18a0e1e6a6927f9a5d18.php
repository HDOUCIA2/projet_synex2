<?php $__env->startSection('html-lang', 'fr'); ?>
<?php $__env->startSection('title', $event->exists ? 'Modifier un événement' : 'Saisir un événement'); ?>

<?php $__env->startSection('content'); ?>
<?php ($editing = $event->exists); ?>

<div class="d-flex flex-wrap justify-content-between align-items-center gap-4 mb-6">
  <div>
    <h4 class="mb-1"><?php echo e($editing ? 'Modifier un événement' : 'Saisir un événement'); ?></h4>
    <p class="text-muted mb-0">
      <?php if(auth()->user()->isAdmin()): ?>
        Les champs marqués d’un astérisque sont obligatoires.
      <?php else: ?>
        Votre contribution sera publiée après validation par un administrateur. Les champs marqués d’un astérisque sont obligatoires.
      <?php endif; ?>
    </p>
  </div>
  <a href="<?php echo e(route('admin.events.index')); ?>" class="btn btn-outline-secondary">Retour à la liste</a>
</div>

<?php if(session('status')): ?>
  <div class="alert alert-success" role="status"><?php echo e(session('status')); ?></div>
<?php endif; ?>

<?php if($editing && $event->status === 'rejected' && $event->review_notes): ?>
  <div class="alert alert-warning" role="status">
    <strong>Motif du refus :</strong> <?php echo e($event->review_notes); ?>

    <div>En enregistrant les corrections, l’événement sera soumis à nouveau à validation.</div>
  </div>
<?php endif; ?>

<?php if($errors->any()): ?>
  <div class="alert alert-danger" role="alert">
    <ul class="mb-0">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

<?php if(auth()->user()->isAdmin()): ?>
  <div class="d-flex flex-wrap align-items-center gap-2 mb-4">
    <span class="text-muted me-1">Gérer les référentiels :</span>
    <?php $__currentLoopData = [
      'provinces' => 'Provinces',
      'event-types' => 'Types',
      'sub-events' => 'Sous-événements',
      'other-events' => 'Autres événements',
      'themes' => 'Thématiques',
      'subthemes' => 'Sous-thématiques',
      'actors' => 'Acteurs',
    ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $catalog => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <a href="<?php echo e(route('admin.references.index', $catalog)); ?>" class="btn btn-sm btn-outline-primary"><?php echo e($label); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </div>
<?php endif; ?>

<form method="POST" action="<?php echo e($editing ? route('admin.events.update', $event) : route('admin.events.store')); ?>">
  <?php echo csrf_field(); ?>
  <?php if($editing): ?>
    <?php echo method_field('PUT'); ?>
  <?php endif; ?>
  <div class="card mb-6">
    <div class="card-header"><h5 class="card-title mb-0">Classification</h5></div>
    <div class="card-body row g-4">
      <?php if(auth()->user()->isAdmin()): ?>
        <?php ($publicationStatus = old('status', $event->exists ? $event->status : 'approved')); ?>
        <div class="col-md-4">
          <label for="status" class="form-label">Publication</label>
          <select id="status" name="status" class="form-select" required>
            <option value="pending" <?php if($publicationStatus === 'pending'): echo 'selected'; endif; ?>>Ne pas publier — en attente</option>
            <option value="approved" <?php if($publicationStatus === 'approved'): echo 'selected'; endif; ?>>Publier sur le tableau public</option>
            <?php if($editing && $event->status === 'rejected'): ?>
              <option value="rejected" <?php if($publicationStatus === 'rejected'): echo 'selected'; endif; ?>>Refusé</option>
            <?php endif; ?>
          </select>
        </div>
      <?php endif; ?>
      <div class="col-md-4">
        <label for="event_year" class="form-label">Année *</label>
        <input id="event_year" name="event_year" type="number" min="1900" max="2100" class="form-control" value="<?php echo e(old('event_year', $event->event_year)); ?>" required>
      </div>
      <div class="col-md-4">
        <label for="event_date_raw" class="form-label">Date de l’événement</label>
        <input id="event_date_raw" name="event_date_raw" type="text" class="form-control" value="<?php echo e(old('event_date_raw', $event->event_date_raw)); ?>" placeholder="Ex. 12-mai-25">
      </div>
      <div class="col-md-4">
        <label for="province_id" class="form-label">Province *</label>
        <select id="province_id" name="province_id" class="form-select" required>
          <option value="">Choisir…</option>
          <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($province->id); ?>" <?php if(old('province_id', $provinces->firstWhere('name', $event->province)?->id) == $province->id): echo 'selected'; endif; ?>><?php echo e($province->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-md-6">
        <label for="event_type_id" class="form-label">Type d’événement *</label>
        <select id="event_type_id" name="event_type_id" class="form-select" required>
          <option value="">Choisir…</option>
          <?php $__currentLoopData = $eventTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($type->id); ?>" <?php if(old('event_type_id', $event->event_type_id) == $type->id): echo 'selected'; endif; ?>><?php echo e($type->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-md-6">
        <label for="sub_event_id" class="form-label">Sous-événement</label>
        <select id="sub_event_id" name="sub_event_id" class="form-select">
          <option value="">Aucun</option>
          <?php $__currentLoopData = $eventTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $type->subEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subEvent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($subEvent->id); ?>" <?php if(old('sub_event_id', $event->sub_event_id) == $subEvent->id): echo 'selected'; endif; ?>><?php echo e($type->name); ?> — <?php echo e($subEvent->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-md-6">
        <label for="other_event_id" class="form-label">Autre événement</label>
        <select id="other_event_id" name="other_event_id" class="form-select">
          <option value="">Aucun</option>
          <?php $__currentLoopData = $otherEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherEvent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($otherEvent->id); ?>" <?php if(old('other_event_id', $event->other_event_id) == $otherEvent->id): echo 'selected'; endif; ?>><?php echo e($otherEvent->description); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-md-6">
        <label for="theme_id" class="form-label">Thématique *</label>
        <select id="theme_id" name="theme_id" class="form-select" required>
          <option value="">Choisir…</option>
          <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($theme->id); ?>" <?php if(old('theme_id', $event->theme_id) == $theme->id): echo 'selected'; endif; ?>><?php echo e($theme->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-md-6">
        <label for="subtheme_id" class="form-label">Sous-thématique</label>
        <select id="subtheme_id" name="subtheme_id" class="form-select">
          <option value="">Aucune</option>
          <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php $__currentLoopData = $theme->subthemes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subtheme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($subtheme->id); ?>" <?php if(old('subtheme_id', $event->subtheme_id) == $subtheme->id): echo 'selected'; endif; ?>><?php echo e($theme->name); ?> — <?php echo e($subtheme->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-md-6">
        <label for="time_period" class="form-label">Période / heure</label>
        <input id="time_period" name="time_period" type="number" min="0" class="form-control" value="<?php echo e(old('time_period', $event->time_period)); ?>">
      </div>
    </div>
  </div>

  <div class="card mb-6">
    <div class="card-header"><h5 class="card-title mb-0">Lieu et coordonnées</h5></div>
    <div class="card-body row g-4">
      <?php $__currentLoopData = ['department' => 'Département', 'commune' => 'Commune', 'locality' => 'Localité', 'neighborhood' => 'Quartier', 'street' => 'Rue']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
          <label for="<?php echo e($field); ?>" class="form-label"><?php echo e($label); ?></label>
          <input id="<?php echo e($field); ?>" name="<?php echo e($field); ?>" type="text" class="form-control" value="<?php echo e(old($field, $event->{$field})); ?>">
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-4">
        <label for="latitude" class="form-label">Latitude</label>
        <input id="latitude" name="latitude" type="number" step="any" min="-90" max="90" class="form-control" value="<?php echo e(old('latitude', $event->latitude)); ?>">
      </div>
      <div class="col-md-4">
        <label for="longitude" class="form-label">Longitude</label>
        <input id="longitude" name="longitude" type="number" step="any" min="-180" max="180" class="form-control" value="<?php echo e(old('longitude', $event->longitude)); ?>">
      </div>
      <div class="col-md-4">
        <label for="geoprecision" class="form-label">Précision géographique</label>
        <input id="geoprecision" name="geoprecision" type="number" min="0" max="255" class="form-control" value="<?php echo e(old('geoprecision', $event->geoprecision)); ?>">
      </div>
    </div>
  </div>

  <div class="card mb-6">
    <div class="card-header"><h5 class="card-title mb-0">Acteurs</h5></div>
    <div class="card-body row g-4">
      <?php $__currentLoopData = [1, 2]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $number): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6">
          <label for="actor_<?php echo e($number); ?>_id" class="form-label">Acteur <?php echo e($number); ?></label>
          <select id="actor_<?php echo e($number); ?>_id" name="actor_<?php echo e($number); ?>_id" class="form-select">
            <option value="">Aucun</option>
            <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($actor->id); ?>" <?php if(old("actor_{$number}_id", $event->{"actor_{$number}_id"}) == $actor->id): echo 'selected'; endif; ?>><?php echo e($actor->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
        <div class="col-md-3">
          <label for="association_<?php echo e($number); ?>" class="form-label">Association <?php echo e($number); ?></label>
          <input id="association_<?php echo e($number); ?>" name="association_<?php echo e($number); ?>" type="text" class="form-control" value="<?php echo e(old("association_{$number}", $event->{"association_{$number}"})); ?>">
        </div>
        <div class="col-md-3">
          <label for="interaction_<?php echo e($number); ?>" class="form-label">Interaction <?php echo e($number); ?></label>
          <input id="interaction_<?php echo e($number); ?>" name="interaction_<?php echo e($number); ?>" type="text" class="form-control" value="<?php echo e(old("interaction_{$number}", $event->{"interaction_{$number}"})); ?>">
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>

  <div class="card mb-6">
    <div class="card-header"><h5 class="card-title mb-0">Impacts et source</h5></div>
    <div class="card-body row g-4">
      <?php $__currentLoopData = ['deaths' => 'Décès', 'injuries' => 'Blessés', 'kidnappings' => 'Enlèvements', 'arrests' => 'Arrestations', 'property_damage' => 'Dégâts matériels', 'sexual_violence' => 'Violences sexuelles', 'displaced_people' => 'Personnes déplacées']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $field => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6 col-lg-3">
          <label for="<?php echo e($field); ?>" class="form-label"><?php echo e($label); ?></label>
          <input id="<?php echo e($field); ?>" name="<?php echo e($field); ?>" type="number" min="0" class="form-control" value="<?php echo e(old($field, $event->{$field})); ?>">
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <div class="col-md-6">
        <label for="source" class="form-label">Source</label>
        <input id="source" name="source" type="text" class="form-control" value="<?php echo e(old('source', $event->source)); ?>">
      </div>
      <div class="col-md-6">
        <label for="source_type" class="form-label">Type de source</label>
        <input id="source_type" name="source_type" type="text" class="form-control" value="<?php echo e(old('source_type', $event->source_type)); ?>">
      </div>
      <div class="col-12">
        <label for="source_url_1" class="form-label">Lien vers la source</label>
        <input id="source_url_1" name="source_url_1" type="url" class="form-control" value="<?php echo e(old('source_url_1', $event->source_url_1)); ?>">
      </div>
      <div class="col-12">
        <label for="event_notes" class="form-label">Notes</label>
        <textarea id="event_notes" name="event_notes" class="form-control" rows="4"><?php echo e(old('event_notes', $event->event_notes)); ?></textarea>
      </div>
      <div class="col-12 form-check ms-3">
        <input id="pastoral" name="pastoral" type="checkbox" class="form-check-input" value="1" <?php if(old('pastoral', $event->pastoral)): echo 'checked'; endif; ?>>
        <label for="pastoral" class="form-check-label">Événement lié au pastoralisme</label>
      </div>
    </div>
  </div>

  <div class="d-flex flex-wrap gap-3 mb-6">
    <button type="submit" class="btn btn-primary"><?php echo e($editing ? 'Enregistrer les modifications' : 'Enregistrer l’événement'); ?></button>
    <a href="<?php echo e(route('admin.events.index')); ?>" class="btn btn-outline-secondary">Annuler</a>
  </div>
</form>

<?php if($editing): ?>
  <form method="POST" action="<?php echo e(route('admin.events.destroy', $event)); ?>">
    <?php echo csrf_field(); ?>
    <?php echo method_field('DELETE'); ?>
    <button type="submit" class="btn btn-outline-danger">Supprimer l’événement</button>
  </form>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/content/admin/events/form.blade.php ENDPATH**/ ?>