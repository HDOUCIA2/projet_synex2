<?php $__env->startSection('html-lang', 'fr'); ?>
<?php $__env->startSection('title', 'Importer des événements'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-4 mb-6">
  <div>
    <h4 class="mb-1">Importer des événements</h4>
    <p class="text-muted mb-0">Téléversez un CSV, vérifiez le bilan, puis confirmez l’ajout.</p>
  </div>
  <a href="<?php echo e(route('admin.import.template')); ?>" class="btn btn-outline-primary">
    <i class="icon-base bx bx-download me-1"></i> Télécharger le modèle CSV
  </a>
</div>

<?php if(session('status')): ?>
  <div class="alert alert-success" role="status"><?php echo e(session('status')); ?></div>
<?php endif; ?>

<?php if($errors->any()): ?>
  <div class="alert alert-danger" role="alert">
    <ul class="mb-0">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

<div class="card mb-6">
  <div class="card-header">
    <h5 class="card-title mb-0">Étape 1 — Vérifier un fichier</h5>
  </div>
  <div class="card-body">
    <p>Le fichier doit respecter les colonnes du modèle et utiliser le point-virgule comme séparateur. Les lignes sans année ou sans province seront ignorées et comptées dans le bilan.</p>
    <form method="POST" action="<?php echo e(route('admin.import.preview')); ?>" enctype="multipart/form-data" class="row g-4 align-items-end">
      <?php echo csrf_field(); ?>
      <div class="col-md-8">
        <label for="csv_file" class="form-label">Fichier CSV (20 Mo maximum)</label>
        <input id="csv_file" name="csv_file" type="file" class="form-control" accept=".csv,text/csv" required>
      </div>
      <div class="col-md-4">
        <button type="submit" class="btn btn-primary">Vérifier le fichier</button>
      </div>
    </form>
  </div>
</div>

<?php if(isset($previewOutput)): ?>
  <div class="card border-primary">
    <div class="card-header">
      <h5 class="card-title mb-0">Étape 2 — Confirmer l’import</h5>
    </div>
    <div class="card-body">
      <p class="mb-4"><?php echo e($previewOutput); ?></p>
      <?php if(auth()->user()->isAdmin()): ?>
        <p class="text-muted">Les événements seront ajoutés sans remplacer ceux déjà enregistrés. Le même fichier ne peut être importé deux fois.</p>
      <?php else: ?>
        <p class="text-muted">Les événements seront soumis à validation par un administrateur avant publication. Le fichier doit utiliser les valeurs de référentiel actives, déjà enregistrées par l’administration.</p>
      <?php endif; ?>
      <form method="POST" action="<?php echo e(route('admin.import.commit')); ?>" class="d-flex flex-wrap align-items-center gap-3">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="upload_id" value="<?php echo e($uploadId); ?>">
        <div class="form-check">
          <input id="confirm_import" name="confirm_import" type="checkbox" class="form-check-input" value="1" required>
          <label for="confirm_import" class="form-check-label">Je confirme l’ajout des événements validés.</label>
        </div>
        <button type="submit" class="btn btn-primary">Importer maintenant</button>
      </form>
    </div>
  </div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/content/admin/import/index.blade.php ENDPATH**/ ?>