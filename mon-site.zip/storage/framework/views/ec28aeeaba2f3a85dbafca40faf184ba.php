<?php $__env->startSection('html-lang', 'fr'); ?>
<?php $__env->startSection('title', $config['title']); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-4 mb-6">
  <div>
    <h4 class="mb-1">Référentiels — <?php echo e($config['title']); ?></h4>
    <p class="text-muted mb-0">Ces valeurs sont utilisées lors de la saisie et de l’import des événements.</p>
  </div>
</div>

<div class="d-flex flex-wrap gap-2 mb-6">
  <?php $__currentLoopData = [
    'provinces' => 'Provinces',
    'event-types' => 'Types',
    'sub-events' => 'Sous-événements',
    'other-events' => 'Autres',
    'themes' => 'Thématiques',
    'subthemes' => 'Sous-thématiques',
    'actors' => 'Acteurs',
  ]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <a class="btn btn-sm <?php echo e($catalog === $key ? 'btn-primary' : 'btn-outline-primary'); ?>" href="<?php echo e(route('admin.references.index', $key)); ?>"><?php echo e($label); ?></a>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php if(session('status')): ?>
  <div class="alert alert-success" role="status"><?php echo e(session('status')); ?></div>
<?php endif; ?>

<?php if($errors->any()): ?>
  <div class="alert alert-danger" role="alert">
    <ul class="mb-0">
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
<?php endif; ?>

<div class="card mb-6">
  <div class="card-header">
    <h5 class="card-title mb-0">Ajouter une valeur</h5>
  </div>
  <div class="card-body">
    <form method="POST" action="<?php echo e(route('admin.references.store', $catalog)); ?>" class="row g-4 align-items-end">
      <?php echo csrf_field(); ?>
      <?php if(isset($config['parent'])): ?>
        <div class="col-md-4">
          <label for="parent_id" class="form-label"><?php echo e($config['parent']['label']); ?></label>
          <select id="parent_id" name="<?php echo e($config['parent']['field']); ?>" class="form-select" required>
            <option value="">Choisir…</option>
            <?php $__currentLoopData = $parentOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($parent->id); ?>" <?php if(old($config['parent']['field']) == $parent->id): echo 'selected'; endif; ?>><?php echo e($parent->name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>
      <?php endif; ?>
      <div class="col-md">
        <label for="new_value" class="form-label"><?php echo e($config['label']); ?></label>
        <input id="new_value" name="<?php echo e($config['field']); ?>" type="text" class="form-control" value="<?php echo e(old($config['field'])); ?>" maxlength="<?php echo e($catalog === 'other-events' ? 2000 : 255); ?>" required>
      </div>
      <div class="col-md-auto">
        <button type="submit" class="btn btn-primary">Ajouter</button>
      </div>
    </form>
  </div>
</div>

<div class="card">
  <div class="card-header d-flex justify-content-between align-items-center">
    <h5 class="card-title mb-0">Valeurs existantes</h5>
    <span class="badge bg-label-primary"><?php echo e(number_format($items->total(), 0, ',', ' ')); ?></span>
  </div>
  <div class="card-body">
    <?php $__empty_1 = true; $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
      <div class="border rounded p-3 mb-3">
        <div class="mb-3">
          <span class="badge <?php echo e($item->is_active ? 'bg-label-success' : 'bg-label-danger'); ?>">
            <?php echo e($item->is_active ? 'Actif' : 'Bloqué'); ?>

          </span>
        </div>
        <div class="d-flex flex-wrap gap-3 align-items-end">
          <form id="update-<?php echo e($item->id); ?>" method="POST" action="<?php echo e(route('admin.references.update', [$catalog, $item->id])); ?>" class="row g-3 align-items-end flex-grow-1">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>
            <?php if(isset($config['parent'])): ?>
              <div class="col-md-4">
                <label for="parent-<?php echo e($item->id); ?>" class="form-label"><?php echo e($config['parent']['label']); ?></label>
                <select id="parent-<?php echo e($item->id); ?>" name="<?php echo e($config['parent']['field']); ?>" class="form-select" required>
                  <?php $__currentLoopData = $parentOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($parent->id); ?>" <?php if($item->{$config['parent']['field']} == $parent->id): echo 'selected'; endif; ?>><?php echo e($parent->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
              </div>
            <?php endif; ?>
            <div class="col">
              <label for="value-<?php echo e($item->id); ?>" class="form-label"><?php echo e($config['label']); ?></label>
              <input id="value-<?php echo e($item->id); ?>" name="<?php echo e($config['field']); ?>" type="text" class="form-control" value="<?php echo e($item->{$config['field']}); ?>" maxlength="<?php echo e($catalog === 'other-events' ? 2000 : 255); ?>" required>
            </div>
            <?php if(isset($config['parent'])): ?>
              <button type="submit" class="btn btn-outline-primary">Enregistrer</button>
            <?php else: ?>
              <div class="col-auto">
                <button type="submit" class="btn btn-outline-primary">Enregistrer</button>
              </div>
            <?php endif; ?>
          </form>
          <form method="POST" action="<?php echo e(route('admin.references.destroy', [$catalog, $item->id])); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-outline-danger">Supprimer</button>
          </form>
          <form method="POST" action="<?php echo e(route('admin.references.status', [$catalog, $item->id])); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PATCH'); ?>
            <button type="submit" class="btn btn-outline-warning">
              <?php echo e($item->is_active ? 'Bloquer' : 'Réactiver'); ?>

            </button>
          </form>
        </div>
        <?php if(isset($config['parent'])): ?>
          <small class="text-muted"><?php echo e($item->{$config['parent']['relation']}?->name); ?></small>
        <?php endif; ?>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
      <p class="text-muted mb-0">Aucune valeur enregistrée.</p>
    <?php endif; ?>
    <?php echo e($items->links()); ?>

  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/content/admin/references/index.blade.php ENDPATH**/ ?>