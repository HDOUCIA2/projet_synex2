<nav class="navbar navbar-expand-lg bg-white border-bottom sticky-top" aria-label="Navigation principale">
  <div class="container-xxl px-4">
    <a class="navbar-brand fw-bold" href="<?php echo e(route('home')); ?>"><?php echo e($siteSettings->name); ?></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#program-news-navigation" aria-controls="program-news-navigation" aria-expanded="false" aria-label="Afficher la navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="program-news-navigation">
      <ul class="navbar-nav ms-auto align-items-lg-center gap-lg-3">
        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('home')); ?>#aperçu">Accueil</a></li>
        <li class="nav-item"><a class="nav-link" href="<?php echo e(route('veille')); ?>">Veille</a></li>
        <li class="nav-item"><a class="nav-link active" href="<?php echo e(route('program-news.index')); ?>" aria-current="page">Actualités du programme</a></li>
        <li class="nav-item">
          <a href="<?php echo e(route('dashboard-analytics')); ?>" class="btn btn-primary">
            <i class="icon-base bx bx-grid-alt me-1" aria-hidden="true"></i>Salle de situation
          </a>
        </li>
      </ul>
    </div>
  </div>
</nav>
<?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/content/pages/program-news/_navbar.blade.php ENDPATH**/ ?>