<?php $__env->startSection('html-lang', 'fr'); ?>
<?php $__env->startSection('title', 'Gestion des actualités'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-6">
  <div>
    <h4 class="mb-1">Actualités du programme</h4>
    <p class="text-muted mb-0">Créez, modifiez et gérez la publication des actualités.</p>
  </div>
  <div class="d-flex flex-wrap gap-2">
    <a href="<?php echo e(route('program-news.index')); ?>" target="_blank" rel="noopener" class="btn btn-outline-primary">
      <i class="icon-base bx bx-link-external me-1"></i>Voir la page publique
    </a>
    <a href="<?php echo e(route('admin.program-news.create')); ?>" class="btn btn-primary">
      <i class="icon-base bx bx-plus me-1"></i>Nouvelle actualité
    </a>
  </div>
</div>

<?php if(session('status')): ?>
  <div class="alert alert-success" role="status"><?php echo e(session('status')); ?></div>
<?php endif; ?>

<div class="card">
  <div class="table-responsive text-nowrap">
    <table class="table">
      <thead>
        <tr>
          <th>Actualité</th>
          <th>Classement</th>
          <th>Date de publication</th>
          <th>Statut</th>
          <th class="text-end">Actions</th>
        </tr>
      </thead>
      <tbody class="table-border-bottom-0">
        <?php $__empty_1 = true; $__currentLoopData = $newsItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td>
              <div class="d-flex align-items-center gap-3">
                <img src="<?php echo e(asset('storage/'.$news->image_path)); ?>" alt="" class="rounded object-fit-cover" width="64" height="48">
                <div>
                  <strong class="d-block"><?php echo e($news->title); ?></strong>
                  <small class="text-muted"><?php echo e(\Illuminate\Support\Str::limit($news->summary, 90)); ?></small>
                </div>
              </div>
            </td>
            <td>
              <span class="d-block"><?php echo e($news->category ? \App\Models\ProgramNews::CATEGORIES[$news->category] ?? $news->category : 'Non classée'); ?></span>
              <small class="text-muted"><?php echo e($news->region ? \App\Models\ProgramNews::REGIONS[$news->region] ?? $news->region : 'Région non renseignée'); ?></small>
            </td>
            <td><?php echo e($news->published_at->format('d/m/Y H:i')); ?></td>
            <td>
              <span class="badge <?php echo e($news->is_published ? 'bg-label-success' : 'bg-label-secondary'); ?>">
                <?php echo e($news->is_published ? 'Publiée' : 'Dépubliée'); ?>

              </span>
            </td>
            <td>
              <div class="d-flex justify-content-end gap-2">
                <a href="<?php echo e(route('admin.program-news.edit', $news)); ?>" class="btn btn-sm btn-outline-primary">
                  <i class="icon-base bx bx-edit-alt" aria-hidden="true"></i><span class="visually-hidden">Modifier <?php echo e($news->title); ?></span>
                </a>
                <form method="POST" action="<?php echo e(route('admin.program-news.publication', $news)); ?>">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('PATCH'); ?>
                  <button type="submit" class="btn btn-sm <?php echo e($news->is_published ? 'btn-outline-warning' : 'btn-outline-success'); ?>">
                    <i class="icon-base bx <?php echo e($news->is_published ? 'bx-hide' : 'bx-show'); ?>" aria-hidden="true"></i>
                    <span class="visually-hidden"><?php echo e($news->is_published ? 'Dépublier' : 'Publier'); ?> <?php echo e($news->title); ?></span>
                  </button>
                </form>
                <form method="POST" action="<?php echo e(route('admin.program-news.destroy', $news)); ?>">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-sm btn-outline-danger" onclick="return confirm('Supprimer cette actualité ?')">
                    <i class="icon-base bx bx-trash" aria-hidden="true"></i><span class="visually-hidden">Supprimer <?php echo e($news->title); ?></span>
                  </button>
                </form>
              </div>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr><td colspan="5" class="text-center text-muted py-5">Aucune actualité n’a été créée.</td></tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($newsItems->hasPages()): ?>
    <div class="card-footer d-flex flex-column flex-md-row justify-content-between align-items-center gap-3">
      <span class="text-muted small">
        Affichage de <?php echo e($newsItems->firstItem()); ?> à <?php echo e($newsItems->lastItem()); ?> sur <?php echo e($newsItems->total()); ?> actualités
      </span>
      <?php echo e($newsItems->links('pagination::bootstrap-5')); ?>

    </div>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/content/admin/program-news/index.blade.php ENDPATH**/ ?>