<?php $__env->startSection('html-lang', 'fr'); ?>
<?php $__env->startSection('title', 'Gestion de la veille'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-6">
  <div>
    <h4 class="mb-1">Gestion de la veille</h4>
    <p class="text-muted mb-0">Gérez les titres, descriptions, icônes ou images des lectures affichées sur la page Veille.</p>
  </div>
  <a href="<?php echo e(route('veille')); ?>" target="_blank" rel="noopener" class="btn btn-outline-primary">
    <i class="icon-base bx bx-link-external me-1"></i>Voir la page Veille
  </a>
</div>

<?php if(session('status')): ?>
  <div class="alert alert-success" role="status"><?php echo e(session('status')); ?></div>
<?php endif; ?>

<?php if($errors->any()): ?>
  <div class="alert alert-danger" role="alert">
    <ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
  </div>
<?php endif; ?>

<section class="card mb-6">
  <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
    <div>
      <span class="badge bg-label-primary mb-2">Page Veille</span>
      <h5 class="card-title mb-0"><?php echo e($section->title); ?></h5>
    </div>
    <span class="badge <?php echo e($section->is_active ? 'bg-label-success' : 'bg-label-secondary'); ?>">
      <?php echo e($section->is_active ? 'Publiée' : 'Dépubliée'); ?>

    </span>
  </div>
  <div class="card-body">
    <form method="POST" action="<?php echo e(route('admin.veille.sections.update', $section)); ?>" class="row g-4">
      <?php echo csrf_field(); ?>
      <?php echo method_field('PUT'); ?>
      <div class="col-12">
        <label class="form-label" for="section-title">Titre</label>
        <input id="section-title" name="title" class="form-control" maxlength="180" value="<?php echo e($section->title); ?>" required>
      </div>
      <div class="col-12">
        <label class="form-label" for="section-description">Description</label>
        <textarea id="section-description" name="description" rows="3" class="form-control" maxlength="10000"><?php echo e($section->description); ?></textarea>
      </div>
      <div class="col-md-6 d-flex align-items-center">
        <div class="form-check">
          <input id="section-active" name="is_active" type="checkbox" class="form-check-input" value="1" <?php if($section->is_active): echo 'checked'; endif; ?>>
          <label for="section-active" class="form-check-label">Publier cette section</label>
        </div>
      </div>
      <div class="col-md-6 text-md-end">
        <button type="submit" class="btn btn-primary">
          <i class="icon-base bx bx-save me-1"></i>Enregistrer les textes
        </button>
      </div>
    </form>
  </div>
</section>

<div class="d-flex flex-wrap justify-content-between align-items-end gap-3 mb-4">
  <div>
    <h5 class="mb-1">Lectures du terrain</h5>
    <p class="text-muted mb-0">Modifiez le texte, publiez ou dépubliez une lecture, ou supprimez-la.</p>
  </div>
  <span class="badge bg-label-secondary"><?php echo e($section->cards->count()); ?> contenu(s)</span>
</div>

<?php $__empty_1 = true; $__currentLoopData = $section->cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
  <section class="card mb-4">
    <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
      <h6 class="card-title mb-0"><?php echo e($card->title); ?></h6>
      <span class="badge <?php echo e($card->is_active ? 'bg-label-success' : 'bg-label-secondary'); ?>">
        <?php echo e($card->is_active ? 'Publiée' : 'Dépubliée'); ?>

      </span>
    </div>
    <div class="card-body">
      <form method="POST" action="<?php echo e(route('admin.veille.cards.update', $card)); ?>" class="row g-3" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>
        <div class="col-md-4">
          <label for="card-title-<?php echo e($card->id); ?>" class="form-label">Titre</label>
          <input id="card-title-<?php echo e($card->id); ?>" name="title" class="form-control" maxlength="180" value="<?php echo e($card->title); ?>" required>
        </div>
        <div class="col-md-8">
          <label for="card-description-<?php echo e($card->id); ?>" class="form-label">Description</label>
          <textarea id="card-description-<?php echo e($card->id); ?>" name="description" rows="2" class="form-control" maxlength="10000"><?php echo e($card->description); ?></textarea>
        </div>
        <div class="col-md-4">
          <label for="card-icon-<?php echo e($card->id); ?>" class="form-label">Icône</label>
          <select id="card-icon-<?php echo e($card->id); ?>" name="icon" class="form-select" required>
            <?php $__currentLoopData = $icons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($icon); ?>" <?php if($card->icon === $icon): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          <span class="form-text">L’icône est utilisée lorsqu’aucune image n’est choisie.</span>
        </div>
        <div class="col-md-8">
          <label for="card-image-<?php echo e($card->id); ?>" class="form-label">Image (facultative)</label>
          <input id="card-image-<?php echo e($card->id); ?>" name="image" type="file" accept=".jpg,.jpeg,.png,.webp" class="form-control">
          <span class="form-text">JPG, PNG ou WEBP, 4 Mo maximum.</span>
          <?php if($card->image_path): ?>
            <div class="d-flex align-items-center gap-3 mt-3">
              <img src="<?php echo e(asset('storage/'.$card->image_path)); ?>" alt="Image actuelle de <?php echo e($card->title); ?>" class="img-thumbnail" width="72" height="72" style="object-fit: cover">
              <div class="form-check">
                <input id="card-remove-image-<?php echo e($card->id); ?>" name="remove_image" type="checkbox" class="form-check-input" value="1">
                <label for="card-remove-image-<?php echo e($card->id); ?>" class="form-check-label">Retirer l’image et utiliser l’icône</label>
              </div>
            </div>
          <?php endif; ?>
        </div>
        <div class="col-md-6 d-flex align-items-center">
          <div class="form-check">
            <input id="card-active-<?php echo e($card->id); ?>" name="is_active" type="checkbox" class="form-check-input" value="1" <?php if($card->is_active): echo 'checked'; endif; ?>>
            <label for="card-active-<?php echo e($card->id); ?>" class="form-check-label">Publier cette lecture</label>
          </div>
        </div>
        <div class="col-md-6 d-flex justify-content-md-end gap-2">
          <button type="submit" class="btn btn-primary">
            <i class="icon-base bx bx-save me-1"></i>Enregistrer
          </button>
          <button type="submit" form="delete-card-<?php echo e($card->id); ?>" class="btn btn-outline-danger">
            <i class="icon-base bx bx-trash me-1"></i>Supprimer
          </button>
        </div>
      </form>
      <form id="delete-card-<?php echo e($card->id); ?>" method="POST" action="<?php echo e(route('admin.veille.cards.destroy', $card)); ?>">
        <?php echo csrf_field(); ?>
        <?php echo method_field('DELETE'); ?>
      </form>
    </div>
  </section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
  <div class="alert alert-info">Aucune lecture n’est encore créée.</div>
<?php endif; ?>

<section class="card">
  <div class="card-header">
    <h5 class="card-title mb-0">Ajouter une lecture</h5>
  </div>
  <div class="card-body">
    <form method="POST" action="<?php echo e(route('admin.veille.cards.store', $section)); ?>" class="row g-3" enctype="multipart/form-data">
      <?php echo csrf_field(); ?>
      <div class="col-md-4">
        <label for="new-card-title" class="form-label">Titre</label>
        <input id="new-card-title" name="title" class="form-control" maxlength="180" required>
      </div>
      <div class="col-md-8">
        <label for="new-card-description" class="form-label">Description</label>
        <textarea id="new-card-description" name="description" rows="2" class="form-control" maxlength="10000"></textarea>
      </div>
      <div class="col-md-4">
        <label for="new-card-icon" class="form-label">Icône</label>
        <select id="new-card-icon" name="icon" class="form-select" required>
          <?php $__currentLoopData = $icons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $icon => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($icon); ?>" <?php if($icon === 'bx-book-open'): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-md-8">
        <label for="new-card-image" class="form-label">Image (facultative)</label>
        <input id="new-card-image" name="image" type="file" accept=".jpg,.jpeg,.png,.webp" class="form-control">
        <span class="form-text">JPG, PNG ou WEBP, 4 Mo maximum. L’image remplace l’icône sur la page publique.</span>
      </div>
      <div class="col-md-6 d-flex align-items-center">
        <div class="form-check">
          <input id="new-card-active" name="is_active" type="checkbox" class="form-check-input" value="1" checked>
          <label for="new-card-active" class="form-check-label">Publier cette lecture immédiatement</label>
        </div>
      </div>
      <div class="col-md-6 text-md-end">
        <button type="submit" class="btn btn-outline-primary">
          <i class="icon-base bx bx-plus me-1"></i>Ajouter la lecture
        </button>
      </div>
    </form>
  </div>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/content/admin/veille/index.blade.php ENDPATH**/ ?>