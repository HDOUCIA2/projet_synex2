<footer class="synex-public-footer">
  <div class="container-xxl px-4">
    <div class="row g-4 py-4 py-lg-5">
      <div class="col-lg-5">
        <a href="<?php echo e(route('home')); ?>" class="synex-public-footer-brand">
          <span class="synex-public-footer-logo" aria-hidden="true"><?php echo $__env->make('_partials.macros', ['width' => 38, 'variant' => 'dore'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>
          <span>
            <strong><?php echo e($siteSettings->name); ?></strong>
            <small>Suivi &amp; Analyse des Conflits</small>
          </span>
        </a>
        <p class="synex-public-footer-description">
          Des données et des analyses pour mieux comprendre les dynamiques territoriales au Tchad.
        </p>
      </div>

      <nav class="col-6 col-lg-3" aria-label="Liens de pied de page">
        <h2>Explorer</h2>
        <a href="<?php echo e(route('home')); ?>">Accueil</a>
        <a href="<?php echo e(route('dashboard-analytics')); ?>">Tableau de bord</a>
        <a href="<?php echo e(route('veille')); ?>">Veille</a>
        <a href="<?php echo e(route('program-news.index')); ?>">Actualités du programme</a>
      </nav>

      <div class="col-6 col-lg-4">
        <h2>Contact</h2>
        <?php if($siteSettings->address): ?><p><?php echo e($siteSettings->address); ?></p><?php endif; ?>
        <?php if($siteSettings->location): ?><p><?php echo e($siteSettings->location); ?></p><?php endif; ?>
        <?php if($siteSettings->contact_phone): ?><a href="tel:<?php echo e($siteSettings->contact_phone); ?>"><?php echo e($siteSettings->contact_phone); ?></a><?php endif; ?>
        <?php if($siteSettings->contact_email): ?><a href="mailto:<?php echo e($siteSettings->contact_email); ?>"><?php echo e($siteSettings->contact_email); ?></a><?php endif; ?>
      </div>
    </div>

    <div class="synex-public-footer-bottom">
      <span>© <?php echo e(date('Y')); ?> <?php echo e($siteSettings->name); ?>. Tous droits réservés.</span>
      <span>Suivi &amp; Analyse des Conflits · Tchad</span>
    </div>
  </div>
</footer>
<?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/content/pages/_public-footer.blade.php ENDPATH**/ ?>