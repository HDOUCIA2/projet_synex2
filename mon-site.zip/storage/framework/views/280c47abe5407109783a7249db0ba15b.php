<?php $__env->startSection('html-lang', 'fr'); ?>
<?php $__env->startSection('title', 'Connexion'); ?>

<?php $__env->startSection('page-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/scss/pages/page-auth.scss']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-xxl">
    <div class="authentication-wrapper authentication-basic container-p-y">
        <div class="authentication-inner">
            <!-- Register -->
            <div class="card px-sm-6 px-0">
                <div class="card-body">
                    <!-- Logo -->
                    <div class="app-brand justify-content-center">
                        <a href="<?php echo e(url('/')); ?>" class="app-brand-link gap-2">
                            <span class="app-brand-logo demo"><?php echo $__env->make('_partials.macros', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>
                            <span class="app-brand-text demo text-heading fw-bold"><?php echo e($siteSettings->name); ?></span>
                        </a>
                    </div>
                    <!-- /Logo -->
                    <h4 class="mb-1">Connexion à <?php echo e($siteSettings->name); ?></h4>
                    <p class="mb-6">Connectez-vous pour accéder à l’administration.</p>

                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert"><?php echo e($errors->first()); ?></div>
                    <?php endif; ?>

                    <form id="formAuthentication" class="mb-6" action="<?php echo e(route('auth.authenticate')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-6">
                            <label for="identifier" class="form-label">Identifiant</label>
                            <input type="text" class="form-control" id="identifier" name="identifier" value="<?php echo e(old('identifier')); ?>" placeholder="Nom d’utilisateur ou e-mail" autocomplete="username" autofocus required />
                        </div>
                        <div class="mb-6 form-password-toggle">
                            <label class="form-label" for="password">Mot de passe</label>
                            <div class="input-group input-group-merge">
                                <input type="password" id="password" class="form-control" name="password" placeholder="Votre mot de passe" autocomplete="current-password" required />
                                <span class="input-group-text cursor-pointer"><i class="icon-base bx bx-hide"></i></span>
                            </div>
                        </div>
                        <div class="mb-8">
                            <div class="form-check mb-0">
                                <input class="form-check-input" type="checkbox" id="remember-me" name="remember" value="1" <?php if(old('remember')): echo 'checked'; endif; ?> />
                                <label class="form-check-label" for="remember-me">Se souvenir de moi</label>
                            </div>
                        </div>
                        <div class="mb-6">
                            <button class="btn btn-primary d-grid w-100" type="submit">Se connecter</button>
                        </div>
                    </form>

                    <p class="text-center mb-0">
                        Pas encore de profil ?
                        <a href="<?php echo e(route('auth-register-basic')); ?>">Créer un compte utilisateur</a>
                    </p>
                </div>
            </div>
            <!-- /Register -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/blankLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/content/authentications/auth-login-basic.blade.php ENDPATH**/ ?>