<!--  Brand demo (display only for navbar-full and hide on below xl) -->
<?php if(isset($navbarFull)): ?>
<div class="navbar-brand app-brand demo d-none d-xl-flex py-0 me-4">
    <a href="<?php echo e(url('/')); ?>" class="app-brand-link gap-2">
        <span class="app-brand-logo demo"><?php echo $__env->make('_partials.macros', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>
        <span class="app-brand-text demo menu-text fw-bold text-heading"><?php echo e($siteSettings->name); ?></span>
    </a>
</div>
<?php endif; ?>

<!-- ! Not required for layout-without-menu -->
<?php if(!isset($navbarHideToggle)): ?>
<div class="layout-menu-toggle navbar-nav align-items-xl-center me-4 me-xl-0 <?php echo e(isset($contentNavbar) ?' d-xl-none ' : ''); ?>">
    <a class="nav-item nav-link px-0 me-xl-6" href="javascript:void(0)">
        <i class="icon-base bx bx-menu icon-md"></i>
    </a>
</div>
<?php endif; ?>

<div class="navbar-nav-right d-flex align-items-center" id="navbar-collapse">
    <!-- Search -->
    <div class="navbar-nav align-items-center">
        <div class="nav-item d-flex align-items-center">
            <i class="icon-base bx bx-search icon-md"></i>
            <input type="text" class="form-control border-0 shadow-none ps-1 ps-sm-2" placeholder="Search..." aria-label="Search...">
        </div>
    </div>
    <!-- /Search -->
    <ul class="navbar-nav flex-row align-items-center ms-auto">
        <?php if(auth()->guard()->check()): ?>
        <!-- User -->
        <li class="nav-item navbar-dropdown dropdown-user dropdown">
            <a class="nav-link dropdown-toggle hide-arrow p-0" href="javascript:void(0);" data-bs-toggle="dropdown">
                <div class="avatar avatar-online">
                    <img src="<?php echo e(auth()->user()->avatar_path ? asset('storage/'.auth()->user()->avatar_path) : asset('assets/img/avatars/1.png')); ?>" alt="<?php echo e(auth()->user()->name); ?>" class="w-px-40 h-auto rounded-circle">
                </div>
            </a>
            <ul class="dropdown-menu dropdown-menu-end">
                <li>
                    <a class="dropdown-item" href="<?php echo e(route('pages-account-settings-account')); ?>">
                        <div class="d-flex">
                            <div class="flex-shrink-0 me-3">
                                <div class="avatar avatar-online">
                                    <img src="<?php echo e(auth()->user()->avatar_path ? asset('storage/'.auth()->user()->avatar_path) : asset('assets/img/avatars/1.png')); ?>" alt="<?php echo e(auth()->user()->name); ?>" class="w-px-40 h-auto rounded-circle">
                                </div>
                            </div>
                            <div class="flex-grow-1">
                                <h6 class="mb-0"><?php echo e(auth()->user()->name); ?></h6>
                                <small class="text-muted">
                                    <?php echo e(auth()->user()->isAdmin() ? 'Administrateur' : 'Utilisateur'); ?>

                                </small>
                            </div>
                        </div>
                    </a>
                </li>
                <li>
                    <div class="dropdown-divider my-1"></div>
                </li>
                <li>
                    <a class="dropdown-item" href="<?php echo e(route('pages-account-settings-account')); ?>">
                        <i class="icon-base bx bx-user icon-md me-3"></i><span>Mon profil</span>
                    </a>
                </li>
                <li>
                    <a class="dropdown-item" href="<?php echo e(route('admin.events.index')); ?>">
                        <i class="icon-base bx bx-calendar-event icon-md me-3"></i><span>Gérer les événements</span>
                    </a>
                </li>
                <li>
                    <a class="dropdown-item" href="<?php echo e(route('admin.import.index')); ?>">
                        <i class="icon-base bx bx-upload icon-md me-3"></i><span>Importer un CSV</span>
                    </a>
                </li>
                <?php if(auth()->user()->isAdmin()): ?>
                <li>
                    <a class="dropdown-item" href="<?php echo e(route('admin.users.create')); ?>">
                        <i class="icon-base bx bx-user-plus icon-md me-3"></i><span>Créer un compte</span>
                    </a>
                </li>
                <li>
                    <a class="dropdown-item" href="<?php echo e(route('admin.references.index', 'provinces')); ?>">
                        <i class="icon-base bx bx-list-ul icon-md me-3"></i><span>Référentiels</span>
                    </a>
                </li>
                <li>
                    <a class="dropdown-item" href="<?php echo e(route('admin.settings.site.edit')); ?>">
                        <i class="icon-base bx bx-cog icon-md me-3"></i><span>Paramètres du site</span>
                    </a>
                </li>
                <?php endif; ?>
                <li>
                    <div class="dropdown-divider my-1"></div>
                </li>
                <li>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="dropdown-item" type="submit">
                            <i class="icon-base bx bx-power-off icon-md me-3"></i><span>Déconnexion</span>
                        </button>
                    </form>
                </li>
            </ul>
        </li>
        <!--/ User -->
        <?php else: ?>
        <li class="nav-item">
            <a class="btn btn-primary" href="<?php echo e(route('auth-login-basic')); ?>">Connexion</a>
        </li>
        <?php endif; ?>
    </ul>
</div><?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/layouts/sections/navbar/navbar-partial.blade.php ENDPATH**/ ?>