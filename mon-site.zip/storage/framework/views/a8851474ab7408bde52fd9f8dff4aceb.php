<?php $__env->startSection('html-lang', 'fr'); ?>
<?php $__env->startSection('title', $news->title.' — Actualités du programme'); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('content.pages._public-navbar', ['activePage' => 'program-news'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="container-xxl px-4 py-5">
  <nav aria-label="Fil d’Ariane" class="mb-4">
    <ol class="breadcrumb mb-0">
      <li class="breadcrumb-item"><a href="<?php echo e(route('home')); ?>">Accueil</a></li>
      <li class="breadcrumb-item"><a href="<?php echo e(route('program-news.index')); ?>">Actualités du programme</a></li>
      <li class="breadcrumb-item active" aria-current="page"><?php echo e($news->title); ?></li>
    </ol>
  </nav>

  <article class="card">
    <img class="card-img-top object-fit-cover" src="<?php echo e(asset('storage/'.$news->image_path)); ?>" alt="<?php echo e($news->title); ?>" style="max-height: 480px">
    <div class="card-body p-4 p-md-5">
      <p class="card-text text-muted mb-2">
        <i class="icon-base bx bx-calendar me-1" aria-hidden="true"></i><?php echo e($news->published_at->format('d/m/Y')); ?>

      </p>
      <?php if($news->category || $news->region): ?>
        <div class="d-flex flex-wrap gap-2 mb-3">
          <?php if($news->category): ?>
            <span class="badge bg-label-primary"><?php echo e(\App\Models\ProgramNews::CATEGORIES[$news->category] ?? $news->category); ?></span>
          <?php endif; ?>
          <?php if($news->region): ?>
            <span class="badge bg-label-secondary"><?php echo e(\App\Models\ProgramNews::REGIONS[$news->region] ?? $news->region); ?></span>
          <?php endif; ?>
        </div>
      <?php endif; ?>
      <h1 class="card-title mb-3"><?php echo e($news->title); ?></h1>
      <p class="lead"><?php echo e($news->summary); ?></p>
      <div class="card-text"><?php echo nl2br(e($news->content)); ?></div>
      <a href="<?php echo e(route('program-news.index')); ?>" class="btn btn-outline-primary mt-4">
        <i class="icon-base bx bx-arrow-back me-1" aria-hidden="true"></i>Retour aux actualités
      </a>
    </div>
  </article>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/blankLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/content/pages/program-news/show.blade.php ENDPATH**/ ?>