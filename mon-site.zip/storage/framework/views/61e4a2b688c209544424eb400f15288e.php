<?php
use Illuminate\Support\Facades\Route;
?>
<aside id="layout-menu" class="layout-menu menu-vertical menu bg-menu-theme">

    <!-- ! Hide app brand if navbar-full -->
    <div class="app-brand demo">
        <a href="<?php echo e(url('/')); ?>" class="app-brand-link">
            <span class="app-brand-logo demo"><?php echo $__env->make('_partials.macros', ['variant' => 'blanc'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>
            <span class="app-brand-text demo menu-text fw-bold ms-2"><?php echo e($siteSettings->name); ?></span>
        </a>

        <a href="javascript:void(0);" class="layout-menu-toggle menu-link text-large ms-auto d-block d-xl-none">
            <i class="icon-base bx bx-chevron-left icon-sm d-flex align-items-center justify-content-center"></i>
        </a>
    </div>

    <div class="menu-divider mt-0"></div>
    <div class="menu-inner-shadow"></div>

    <ul class="menu-inner py-1">
        <?php $__currentLoopData = $menuData[0]->menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        

        
        <?php if(isset($menu->menuHeader)): ?>
        <li class="menu-header small text-uppercase">
            <span class="menu-header-text"><?php echo e(__($menu->menuHeader)); ?></span>
        </li>
        <?php else: ?>

        
        <?php
        $activeClass = null;
        $currentRouteName = Route::currentRouteName();

        if ($currentRouteName === $menu->slug) {
        $activeClass = 'active';
        }
        elseif (isset($menu->submenu)) {
        if (gettype($menu->slug) === 'array') {
        foreach($menu->slug as $slug){
        if (str_contains($currentRouteName,$slug) and strpos($currentRouteName,$slug) === 0) {
        $activeClass = 'active open';
        }
        }
        }
        else{
        if (str_contains($currentRouteName,$menu->slug) and strpos($currentRouteName,$menu->slug) === 0) {
        $activeClass = 'active open';
        }
        }
        }
        ?>

        
        <li class="menu-item <?php echo e($activeClass); ?>">
            <a href="<?php echo e(isset($menu->url) ? url($menu->url) : 'javascript:void(0);'); ?>" class="<?php echo e(isset($menu->submenu) ? 'menu-link menu-toggle' : 'menu-link'); ?>" <?php if(isset($menu->target) and !empty($menu->target)): ?> target="_blank" <?php endif; ?>>
                <?php if(isset($menu->icon)): ?>
                <i class="<?php echo e($menu->icon); ?>"></i>
                <?php endif; ?>
                <div><?php echo e(isset($menu->name) ? __($menu->name) : ''); ?></div>
                <?php if(isset($menu->badge)): ?>
                <div class="badge rounded-pill bg-<?php echo e($menu->badge[0]); ?> text-uppercase ms-auto"><?php echo e($menu->badge[1]); ?></div>
                <?php endif; ?>
            </a>

            
            <?php if(isset($menu->submenu)): ?>
            <?php echo $__env->make('layouts.sections.menu.submenu',['menu' => $menu->submenu], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
            <?php endif; ?>
        </li>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(auth()->guard()->check()): ?>
        <li class="menu-header small text-uppercase"><span class="menu-header-text">Administration</span></li>
        <li class="menu-item <?php echo e(str_starts_with($currentRouteName, 'admin.events.') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.events.index')); ?>" class="menu-link">
                <i class="menu-icon icon-base bx bx-calendar-event"></i>
                <div>Événements</div>
            </a>
        </li>
        <li class="menu-item <?php echo e(str_starts_with($currentRouteName, 'admin.import.') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.import.index')); ?>" class="menu-link">
                <i class="menu-icon icon-base bx bx-upload"></i>
                <div>Import CSV</div>
            </a>
        </li>
        <?php if(auth()->user()->isAdmin()): ?>
        <li class="menu-item <?php echo e(str_starts_with($currentRouteName, 'admin.references.') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.references.index', 'provinces')); ?>" class="menu-link">
                <i class="menu-icon icon-base bx bx-list-ul"></i>
                <div>Référentiels</div>
            </a>
        </li>
        <li class="menu-item <?php echo e(str_starts_with($currentRouteName, 'admin.veille.') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.veille.index')); ?>" class="menu-link">
                <i class="menu-icon icon-base bx bx-slider-alt"></i>
                <div>Contenu de la veille</div>
            </a>
        </li>
        <li class="menu-item <?php echo e(str_starts_with($currentRouteName, 'admin.program-news.') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.program-news.index')); ?>" class="menu-link">
                <i class="menu-icon icon-base bx bx-news"></i>
                <div>Actualités du programme</div>
            </a>
        </li>
        <li class="menu-item <?php echo e(str_starts_with($currentRouteName, 'admin.users.') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.users.create')); ?>" class="menu-link">
                <i class="menu-icon icon-base bx bx-user-plus"></i>
                <div>Comptes</div>
            </a>
        </li>
        <li class="menu-item <?php echo e(str_starts_with($currentRouteName, 'admin.settings.') ? 'active' : ''); ?>">
            <a href="<?php echo e(route('admin.settings.site.edit')); ?>" class="menu-link">
                <i class="menu-icon icon-base bx bx-cog"></i>
                <div>Réglages du site</div>
            </a>
        </li>
        <?php endif; ?>
        <li class="menu-item <?php echo e($currentRouteName === 'pages-account-settings-account' ? 'active' : ''); ?>">
            <a href="<?php echo e(route('pages-account-settings-account')); ?>" class="menu-link">
                <i class="menu-icon icon-base bx bx-user"></i>
                <div>Mon profil</div>
            </a>
        </li>
        <?php endif; ?>
    </ul>

</aside>
<?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/layouts/sections/menu/verticalMenu.blade.php ENDPATH**/ ?>