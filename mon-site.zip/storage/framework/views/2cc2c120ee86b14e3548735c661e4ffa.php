<?php $__env->startSection('html-lang', 'fr'); ?>
<?php $__env->startSection('title', 'Actualités du programme'); ?>

<?php $__env->startSection('page-style'); ?>
  <?php echo app('Illuminate\Foundation\Vite')('resources/assets/css/program-news.css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php echo $__env->make('content.pages._public-navbar', ['activePage' => 'program-news'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<main class="container-xxl px-4 py-5 synex-news-page">
  <h1 class="visually-hidden">Actualités du programme</h1>
  <form method="GET" action="<?php echo e(route('program-news.index')); ?>" class="card synex-news-filters mb-4">
    <div class="card-body">
      <div class="row g-3 align-items-end">
        <div class="col-lg-4">
          <label for="newsSearch" class="form-label">Rechercher</label>
          <div class="input-group">
            <span class="input-group-text bg-white" aria-hidden="true">
              <i class="icon-base bx bx-search"></i>
            </span>
            <input
              type="search"
              class="form-control"
              id="newsSearch"
              name="q"
              value="<?php echo e($filters['q'] ?? ''); ?>"
              maxlength="120"
              placeholder="Rechercher une actualité..."
            >
          </div>
        </div>

        <div class="col-lg-2 col-md-4">
          <label for="newsCategory" class="form-label">Catégorie</label>
          <select class="form-select" id="newsCategory" name="category">
            <option value="">Toutes les catégories</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($value); ?>" <?php if(($filters['category'] ?? '') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="col-lg-2 col-md-4">
          <label for="newsRegion" class="form-label">Région</label>
          <select class="form-select" id="newsRegion" name="region">
            <option value="">Toutes les régions</option>
            <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($value); ?>" <?php if(($filters['region'] ?? '') === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="col-lg-2 col-md-4">
          <label for="newsDate" class="form-label">Année</label>
          <select class="form-select" id="newsDate" name="year">
            <option value="">Toutes les dates</option>
            <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($year); ?>" <?php if(($filters['year'] ?? null) == $year): echo 'selected'; endif; ?>><?php echo e($year); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </div>

        <div class="col-lg-2">
          <button class="btn btn-primary w-100" type="submit" id="newsSearchButton">
            <i class="icon-base bx bx-search me-1" aria-hidden="true"></i>
            Rechercher
          </button>
        </div>
      </div>
    </div>
  </form>

  <?php if($newsItems->isNotEmpty()): ?>
    <div class="row g-4" id="newsList">
      <?php $__currentLoopData = $newsItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $news): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-6 col-xl-4">
          <article class="card synex-news-card h-100">
            <a class="synex-news-image" href="<?php echo e(route('program-news.show', $news)); ?>" aria-label="Lire l’actualité : <?php echo e($news->title); ?>">
              <?php if($news->image_path): ?>
                <img
                  src="<?php echo e(asset('storage/'.$news->image_path)); ?>"
                  class="card-img-top"
                  alt="<?php echo e($news->title); ?>"
                  loading="lazy"
                >
              <?php else: ?>
                <span class="synex-news-placeholder" aria-hidden="true">
                  <i class="icon-base bx bx-news"></i>
                </span>
              <?php endif; ?>
              <?php if($news->category && isset($categories[$news->category])): ?>
                <span class="badge synex-news-category"><?php echo e($categories[$news->category]); ?></span>
              <?php endif; ?>
            </a>

            <div class="card-body d-flex flex-column">
              <div class="synex-news-meta">
                <span>
                  <i class="icon-base bx bx-calendar me-1" aria-hidden="true"></i>
                  <time datetime="<?php echo e($news->published_at->toDateString()); ?>"><?php echo e($news->published_at->format('d/m/Y')); ?></time>
                </span>
                <?php if($news->region && isset($regions[$news->region])): ?>
                  <span class="synex-news-region"><?php echo e($regions[$news->region]); ?></span>
                <?php endif; ?>
              </div>

              <h2 class="card-title"><?php echo e($news->title); ?></h2>
              <p class="card-text synex-news-summary"><?php echo e($news->summary); ?></p>
              <a href="<?php echo e(route('program-news.show', $news)); ?>" class="synex-news-link mt-auto">
                Lire l’actualité
                <i class="icon-base bx bx-right-arrow-alt ms-1" aria-hidden="true"></i>
              </a>
            </div>
          </article>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    <div class="d-flex flex-column flex-md-row justify-content-between align-items-center gap-3 mt-5">
      <p class="text-muted small mb-0">
        Affichage de <?php echo e($newsItems->firstItem()); ?> à <?php echo e($newsItems->lastItem()); ?> sur <?php echo e($newsItems->total()); ?> actualités
      </p>
      <?php echo e($newsItems->links('pagination::bootstrap-5')); ?>

    </div>
  <?php else: ?>
    <div id="newsEmpty" class="alert alert-light text-center py-5" role="status">
      <i class="icon-base bx bx-info-circle icon-xl mb-2" aria-hidden="true"></i>
      <h2 class="h5">Aucune actualité ne correspond à votre recherche.</h2>
      <p class="text-muted mb-3">Essayez de modifier ou de supprimer un filtre.</p>
      <a href="<?php echo e(route('program-news.index')); ?>" class="btn btn-outline-primary">Afficher toutes les actualités</a>
    </div>
  <?php endif; ?>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/blankLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/content/pages/program-news/index.blade.php ENDPATH**/ ?>