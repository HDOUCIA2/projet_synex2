<?php $__env->startSection('html-lang', 'fr'); ?>
<?php $__env->startSection('title', $siteSettings->name.' — Le conflit, lisible avant la crise'); ?>

<?php $__env->startSection('page-script'); ?>
  <?php echo app('Illuminate\Foundation\Vite')('resources/assets/js/veille-animations.js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')('resources/assets/css/veille.css'); ?>
<style>
  body {
    background: var(--synex-ivory);
    color: var(--synex-muted);
    -webkit-font-smoothing: antialiased;
  }

  .landing-shell {
    min-height: 100vh;
    overflow: hidden;
  }

  .hero-section {
    position: relative;
    background:
      radial-gradient(circle at 82% 18%, rgba(var(--bs-primary-rgb), .12), transparent 26rem),
      linear-gradient(180deg, #FFFFFF 0%, var(--synex-ivory) 100%);
  }

  .hero-copy {
    max-width: 650px;
  }

  .hero-title {
    max-width: 760px;
    letter-spacing: -0.045em;
    line-height: 1.08;
  }

  .hero-title span {
    color: var(--synex-primary);
  }

  .eyebrow {
    display: inline-flex;
    align-items: center;
    gap: 0.55rem;
    font-size: 0.75rem;
    font-weight: 700;
    letter-spacing: 0.09em;
    text-transform: uppercase;
  }

  .eyebrow-dot {
    width: 8px;
    height: 8px;
    flex: 0 0 auto;
    border-radius: 50%;
    background: var(--synex-primary-light);
    box-shadow: 0 0 0 5px rgba(var(--bs-primary-rgb), .13);
  }

  .btn-primary {
    box-shadow: 0 10px 24px rgba(var(--bs-primary-rgb), .22);
  }

  .btn-primary:hover {
    background: var(--synex-primary-dark);
  }

  .landing-shell a:focus-visible,
  .landing-shell button:focus-visible {
    outline: 3px solid rgba(var(--bs-primary-rgb), .55);
    outline-offset: 3px;
  }

  .product-preview {
    position: relative;
    max-width: 580px;
    margin-left: auto;
  }

  .product-preview::before {
    content: "";
    position: absolute;
    inset: 8% -7% -7% 18%;
    z-index: 0;
    border-radius: 2rem;
    background: rgba(var(--bs-primary-rgb), .09);
    transform: rotate(3deg);
  }

  .preview-card {
    position: relative;
    z-index: 1;
    overflow: hidden;
    border: 1px solid rgba(var(--bs-primary-rgb), .12) !important;
    border-radius: 1.25rem;
    box-shadow: 0 1.5rem 4rem rgba(44, 40, 31, .14);
  }

  .preview-toolbar {
    display: flex;
    align-items: center;
    gap: 6px;
  }

  .preview-toolbar span {
    width: 8px;
    height: 8px;
    border-radius: 50%;
    background: var(--synex-border);
  }

  .preview-kpi {
    border: 1px solid var(--synex-border);
    border-radius: 0.875rem;
  }

  .logo-strip {
    border-top: 1px solid var(--synex-border);
    border-bottom: 1px solid var(--synex-border);
  }

  .logo-strip-item {
    color: var(--synex-muted);
    font-size: 0.78rem;
    font-weight: 700;
    letter-spacing: 0.08em;
    text-transform: uppercase;
  }

  .metric-card,
  .feature-card,
  .process-card {
    border: 1px solid var(--synex-border);
    border-radius: 1rem;
    transition: transform 0.2s ease, box-shadow 0.2s ease, border-color 0.2s ease;
  }

  .metric-card:hover,
  .feature-card:hover,
  .process-card:hover {
    transform: translateY(-3px);
    border-color: rgba(var(--bs-primary-rgb), .28);
    box-shadow: 0 1rem 2.5rem rgba(44, 40, 31, .08);
  }

  .feature-icon {
    width: 48px;
    height: 48px;
    border-radius: 14px;
    display: grid;
    place-items: center;
  }

  .process-number {
    width: 34px;
    height: 34px;
    border-radius: 50%;
    display: grid;
    place-items: center;
    background: var(--synex-primary);
    color: #fff;
    font-size: 0.825rem;
    font-weight: 700;
  }

  .cta-panel {
    position: relative;
    overflow: hidden;
    border-radius: 1.5rem;
    background: var(--synex-ink);
  }

  .cta-panel::after {
    content: "";
    position: absolute;
    width: 320px;
    height: 320px;
    right: -180px;
    bottom: -240px;
    border: 60px solid rgba(var(--bs-primary-rgb), .18);
    border-radius: 50%;
  }

  .section-anchor {
    scroll-margin-top: 96px;
  }

  @media (prefers-reduced-motion: reduce) {
    .metric-card,
    .feature-card,
    .process-card {
      transition: none;
    }

    .metric-card:hover,
    .feature-card:hover,
    .process-card:hover {
      transform: none;
    }
  }

  @media (max-width: 991.98px) {
    .hero-title {
      letter-spacing: -0.035em;
    }

    .product-preview {
      max-width: 620px;
      margin: 0 auto;
    }
  }

  @media (max-width: 575.98px) {
    .hero-title {
      font-size: 2.25rem;
    }

  }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="landing-shell">
  <?php echo $__env->make('content.pages._public-navbar', ['activePage' => 'home'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <main>
    <section id="aperçu" class="hero-section section-anchor">
      <div class="container-xxl px-4 py-5 py-lg-6">
        <div class="row align-items-center g-5 py-lg-4">
          <?php
            $hero = $homeSections->get('home_hero');
          ?>
          <?php if($hero?->is_active): ?>
          <div class="col-lg-6">
          <div class="hero-copy">
            <?php if($hero->eyebrow): ?>
            <div class="eyebrow text-primary mb-4" data-veille-animation="fade-up">
              <span class="eyebrow-dot"></span>
              <?php echo e($hero->eyebrow); ?>

            </div>
            <?php endif; ?>
            <h1 class="hero-title display-4 fw-bold mb-4" data-veille-animation="fade-up">
              <?php echo e($hero->title); ?> <span><?php echo e($hero->accent); ?></span>
            </h1>
            <?php if($hero->description): ?><p class="lead text-muted mb-4" data-veille-animation="fade-up"><?php echo e($hero->description); ?></p><?php endif; ?>
            <div class="d-flex flex-wrap gap-3 mb-4">
              <?php if($hero->button_text): ?>
                <a href="<?php echo e(route('dashboard-analytics')); ?>" class="btn btn-primary btn-lg px-4"><?php echo e($hero->button_text); ?> <i class="icon-base bx bx-right-arrow-alt ms-1"></i></a>
              <?php endif; ?>
              <?php if($hero->secondary_button_text): ?>
                <a href="<?php echo e(route('veille')); ?>" class="btn btn-outline-secondary btn-lg px-4"><?php echo e($hero->secondary_button_text); ?></a>
              <?php endif; ?>
            </div>
          </div>
          </div>
          <?php endif; ?>

          <?php
            $preview = $homeSections->get('home_preview');
          ?>
          <?php if($preview?->is_active): ?>
          <div class="col-lg-6">
            <div class="product-preview">
          <div class="card preview-card shadow-sm">
            <div class="card-header bg-white d-flex align-items-center justify-content-between py-3 border-bottom">
              <div class="preview-toolbar" aria-hidden="true">
                <span></span><span></span><span></span>
              </div>
              <span class="badge bg-label-warning"><i class="icon-base bx bx-show me-1"></i>Illustration</span>
            </div>
            <div class="card-body p-4">
              <div class="d-flex align-items-center justify-content-between mb-4">
                <div><h5 class="mb-1"><?php echo e($preview->title); ?></h5><?php if($preview->description): ?><small class="text-muted"><?php echo e($preview->description); ?></small><?php endif; ?></div>
              </div>

              <div class="veille-card-grid">
                <?php $__currentLoopData = $preview->cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <article class="preview-kpi p-3" data-veille-animation="<?php echo e($card->animation); ?>">
                    <?php if($card->icon): ?><i class="icon-base bx <?php echo e($card->icon); ?> text-<?php echo e($card->color); ?> me-1" aria-hidden="true"></i><?php endif; ?>
                    <small class="text-muted d-block mb-2"><?php echo e($card->title); ?></small>
                    <?php if($card->value): ?><div class="fw-bold fs-4 text-<?php echo e($card->color); ?>"><?php echo e($card->value); ?></div><?php endif; ?>
                    <?php if($card->description): ?><p class="small mb-0"><?php echo e($card->description); ?></p><?php endif; ?>
                  </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </div>
              <?php if($preview->secondary_text): ?><p class="text-muted small mt-3 mb-0"><?php echo e($preview->secondary_text); ?></p><?php endif; ?>
            </div>
          </div>
            </div>
          </div>
          <?php endif; ?>
        </div>
      </div>
    </section>

    <?php
      $highlights = $homeSections->get('home_highlights');
    ?>
    <?php if($highlights?->is_active): ?>
    <section class="logo-strip">
      <div class="container-xxl px-4 py-4">
        <div class="row g-3 align-items-center text-center">
          <?php $__currentLoopData = $highlights->cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-6 col-md-3 logo-strip-item" data-veille-animation="<?php echo e($card->animation); ?>"><?php echo e($card->title); ?></div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section>
    <?php endif; ?>

    <?php
      $coverage = $homeSections->get('home_coverage');
    ?>
    <?php if($coverage?->is_active): ?>
    <section id="veille" class="container-xxl px-4 py-5 py-lg-6 section-anchor">
      <div class="row align-items-end mb-4 g-3">
        <div class="col-lg-7">
          <?php if($coverage->eyebrow): ?><span class="eyebrow text-primary" data-veille-animation="fade-up"><?php echo e($coverage->eyebrow); ?></span><?php endif; ?>
          <h2 class="display-6 fw-bold mt-3 mb-0" data-veille-animation="fade-up"><?php echo e($coverage->title); ?></h2>
        </div>
        <div class="col-lg-5">
          <?php if($coverage->secondary_text): ?><p class="text-muted mb-0" data-veille-animation="fade-up"><?php echo e($coverage->secondary_text); ?></p><?php endif; ?>
        </div>
      </div>

      <div class="veille-card-grid">
        <?php $__currentLoopData = $coverage->cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <article class="card veille-content-card metric-card" data-veille-animation="<?php echo e($card->animation); ?>">
            <div class="card-body p-4">
              <?php if($card->value): ?><span class="badge bg-label-<?php echo e($card->color); ?> mb-4"><?php echo e($card->value); ?></span><?php endif; ?>
              <h3 class="h5"><?php echo e($card->title); ?></h3>
              <?php if($card->description): ?><p class="text-muted mb-0"><?php echo e($card->description); ?></p><?php endif; ?>
            </div>
          </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </div>
    </section>
    <?php endif; ?>

    <?php
      $features = $homeSections->get('home_features');
    ?>
    <?php if($features?->is_active): ?>
    <section class="bg-lighter py-5 py-lg-6">
      <div class="container-xxl px-4">
        <div class="text-center mx-auto mb-5" style="max-width: 720px;">
          <?php if($features->eyebrow): ?><span class="eyebrow text-primary" data-veille-animation="fade-up"><?php echo e($features->eyebrow); ?></span><?php endif; ?>
          <h2 class="display-6 fw-bold mt-3 mb-3" data-veille-animation="fade-up"><?php echo e($features->title); ?></h2>
          <?php if($features->description): ?><p class="text-muted mb-0" data-veille-animation="fade-up"><?php echo e($features->description); ?></p><?php endif; ?>
        </div>
        <div class="veille-card-grid">
          <?php $__currentLoopData = $features->cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="card veille-content-card feature-card" data-veille-animation="<?php echo e($card->animation); ?>">
              <div class="card-body p-4 p-xl-5">
                <?php if($card->icon): ?><span class="feature-icon bg-label-<?php echo e($card->color); ?> mb-4"><i class="icon-base bx <?php echo e($card->icon); ?> icon-lg"></i></span><?php endif; ?>
                <h3 class="h5 mb-3"><?php echo e($card->title); ?></h3>
                <?php if($card->description): ?><p class="text-muted mb-0"><?php echo e($card->description); ?></p><?php endif; ?>
              </div>
            </article>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    </section>
    <?php endif; ?>

    <?php
      $severity = $homeSections->get('home_severity');
    ?>
    <?php if($severity?->is_active): ?>
    <section id="methode" class="container-xxl px-4 py-5 py-lg-6 section-anchor">
      <div class="row align-items-center g-5">
        <div class="col-lg-5">
          <?php if($severity->eyebrow): ?><span class="eyebrow text-primary" data-veille-animation="fade-up"><?php echo e($severity->eyebrow); ?></span><?php endif; ?>
          <h2 class="display-6 fw-bold mt-3 mb-4" data-veille-animation="fade-up"><?php echo e($severity->title); ?></h2>
          <?php if($severity->description): ?><p class="text-muted mb-4" data-veille-animation="fade-up"><?php echo e($severity->description); ?></p><?php endif; ?>
          <?php if($severity->button_text): ?><a href="<?php echo e(route('dashboard-analytics')); ?>" class="btn btn-outline-primary" data-veille-animation="fade-up"><?php echo e($severity->button_text); ?> <i class="icon-base bx bx-right-arrow-alt ms-1"></i></a><?php endif; ?>
        </div>
        <div class="col-lg-7">
          <div class="veille-card-grid">
            <?php $__currentLoopData = $severity->cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <article class="card veille-content-card process-card" data-veille-animation="<?php echo e($card->animation); ?>">
                <div class="card-body p-4">
                  <span class="process-number mb-4"><?php echo e($card->value); ?></span>
                  <h3 class="h5"><?php echo e($card->title); ?></h3>
                  <?php if($card->description): ?><p class="text-muted mb-0 small"><?php echo e($card->description); ?></p><?php endif; ?>
                </div>
              </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
      </div>
      <?php if($severity->secondary_text): ?><p class="text-muted small mt-4 mb-0"><?php echo e($severity->secondary_text); ?></p><?php endif; ?>

      <div class="card mt-5" data-veille-animation="fade-up">
        <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-3">
          <div>
            <h3 class="h5 mb-1">Taux annuel par province</h3>
            <p class="card-subtitle mb-0">Décès rapportés pour 100 000 habitants, calculés à partir des données de population administrées.</p>
          </div>
          <?php if($populationYears->isNotEmpty()): ?>
            <form method="GET" action="<?php echo e(route('home')); ?>">
              <label for="population-year" class="visually-hidden">Année du calcul</label>
              <select id="population-year" name="population_year" class="form-select" onchange="this.form.submit()">
                <?php $__currentLoopData = $populationYears; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($year); ?>" <?php if($rateYear == $year): echo 'selected'; endif; ?>><?php echo e($year); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </select>
            </form>
          <?php endif; ?>
        </div>
        <div class="card-body">
          <?php if($deathRates->isNotEmpty()): ?>
            <?php
              $maxRate = max(1, (float) $deathRates->max('rate'));
            ?>
            <div class="veille-card-grid">
              <?php $__currentLoopData = $deathRates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                  $rateWidth = min(100, ($rate['rate'] / $maxRate) * 100);
                ?>
                <article class="border rounded p-3" data-veille-animation="fade-up">
                  <div class="d-flex justify-content-between align-items-start gap-2">
                    <div><h4 class="h6 mb-1"><?php echo e($rate['province']); ?></h4><small class="text-muted"><?php echo e($rate['year']); ?> · <?php echo e(number_format($rate['deaths'], 0, ',', ' ')); ?> décès / <?php echo e(number_format($rate['population'], 0, ',', ' ')); ?> habitants</small></div>
                    <strong class="text-primary text-nowrap"><?php echo e(number_format($rate['rate'], 2, ',', ' ')); ?></strong>
                  </div>
                  <div class="veille-rate-bar mt-3" role="img" aria-label="<?php echo e(number_format($rate['rate'], 2, ',', ' ')); ?> décès pour 100 000 habitants">
                    <span style="--rate-width: <?php echo e($rateWidth); ?>%"></span>
                  </div>
                </article>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
          <?php else: ?>
            <p class="text-muted mb-0">Les taux apparaîtront après la saisie des populations par province et par année dans l’administration.</p>
          <?php endif; ?>
        </div>
      </div>
    </section>
    <?php endif; ?>

    <?php
      $cta = $homeSections->get('home_cta');
    ?>
    <?php if($cta?->is_active): ?>
    <section class="container-xxl px-4 pb-5 pb-lg-6">
      <div class="cta-panel text-white p-4 p-md-5">
        <div class="row align-items-center position-relative" style="z-index: 1;">
          <div class="col-lg-8">
            <?php if($cta->eyebrow): ?><span class="text-white-50 small text-uppercase fw-semibold" data-veille-animation="fade-up"><?php echo e($cta->eyebrow); ?></span><?php endif; ?>
            <h2 class="h1 fw-bold mt-2 mb-2" data-veille-animation="fade-up"><?php echo e($cta->title); ?></h2>
            <?php if($cta->description): ?><p class="text-white-50 mb-0" data-veille-animation="fade-up"><?php echo e($cta->description); ?></p><?php endif; ?>
          </div>
          <div class="col-lg-4 mt-4 mt-lg-0 text-lg-end">
            <?php if($cta->button_text): ?><a href="<?php echo e(route('dashboard-analytics')); ?>" class="btn btn-light btn-lg px-4" data-veille-animation="fade-left"><?php echo e($cta->button_text); ?> <i class="icon-base bx bx-right-arrow-alt ms-1"></i></a><?php endif; ?>
          </div>
        </div>
      </div>
    </section>
    <?php endif; ?>
  </main>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/blankLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/content/pages/landing.blade.php ENDPATH**/ ?>