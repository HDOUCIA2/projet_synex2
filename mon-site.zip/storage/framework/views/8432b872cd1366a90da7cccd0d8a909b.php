<div class="d-flex justify-content-between align-items-center px-6 py-4">
  <span class="badge bg-label-primary"><?php echo e(number_format($events->total(), 0, ',', ' ')); ?> événement(s)</span>
</div>
<div class="table-responsive">
  <table class="table table-sm table-hover align-middle mb-0">
    <thead>
      <tr>
        <th>Année</th>
        <th>Type</th>
        <th>Province / lieu</th>
        <th>Saisi par</th>
        <th>Statut</th>
        <th class="text-end">Actions</th>
      </tr>
    </thead>
    <tbody>
      <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <?php ($isOwner = (int) $event->created_by_user_id === (int) auth()->id()); ?>
        <tr>
          <td><?php echo e($event->event_year); ?></td>
          <td>
            <div class="fw-semibold"><?php echo e($event->eventTypeRecord?->name ?? $event->event_type ?? '—'); ?></div>
            <small class="text-muted"><?php echo e($event->subEventRecord?->name ?? $event->sub_event ?? ''); ?></small>
          </td>
          <td>
            <div><?php echo e($event->province ?? '—'); ?></div>
            <small class="text-muted"><?php echo e($event->locality ?? $event->commune ?? ''); ?></small>
          </td>
          <td>
            <?php if(auth()->user()->isAdmin()): ?>
              <?php echo e($event->creator?->name ?? 'Import CSV'); ?>

            <?php else: ?>
              <?php echo e($isOwner ? ($event->creator?->name ?? auth()->user()->name) : 'Événement publié'); ?>

            <?php endif; ?>
          </td>
          <td>
            <span class="badge <?php echo e($event->status === 'approved' ? 'bg-label-success' : ($event->status === 'rejected' ? 'bg-label-danger' : 'bg-label-warning')); ?>">
              <?php echo e(['pending' => 'En attente', 'approved' => 'Publié', 'rejected' => 'Refusé'][$event->status] ?? $event->status); ?>

            </span>
            <?php if($event->review_notes): ?>
              <small class="d-block text-muted mt-1"><?php echo e($event->review_notes); ?></small>
            <?php endif; ?>
          </td>
          <td>
            <div class="events-actions">
              <?php if(auth()->user()->isAdmin()): ?>
                <?php if($event->status !== 'approved'): ?>
                  <form method="POST" action="<?php echo e(route('admin.events.review', $event)); ?>" data-event-action>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input type="hidden" name="status" value="approved">
                    <button type="submit" class="btn btn-sm btn-outline-success" title="Publier" aria-label="Publier l’événement">
                      <i class="icon-base bx bx-show" aria-hidden="true"></i>
                      Publier
                    </button>
                  </form>
                <?php else: ?>
                  <form method="POST" action="<?php echo e(route('admin.events.review', $event)); ?>" data-event-action>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <input type="hidden" name="status" value="pending">
                    <button type="submit" class="btn btn-sm btn-outline-warning" title="Dépublier" aria-label="Dépublier l’événement">
                      <i class="icon-base bx bx-hide" aria-hidden="true"></i>
                      Dépublier
                    </button>
                  </form>
                <?php endif; ?>
              <?php endif; ?>
              <?php if(auth()->user()->isAdmin() || ($isOwner && $event->status !== 'approved')): ?>
                <a href="<?php echo e(route('admin.events.edit', $event)); ?>" class="btn btn-sm btn-outline-primary" title="Modifier" aria-label="Modifier l’événement">
                  <i class="icon-base bx bx-edit-alt" aria-hidden="true"></i>
                  Modifier
                </a>
                <form method="POST" action="<?php echo e(route('admin.events.destroy', $event)); ?>" data-event-action data-confirm="Voulez-vous vraiment supprimer cet événement ?">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-sm btn-outline-danger" title="Supprimer" aria-label="Supprimer l’événement">
                    <i class="icon-base bx bx-trash" aria-hidden="true"></i>
                    Supprimer
                  </button>
                </form>
              <?php endif; ?>
            </div>
          </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr><td colspan="6" class="text-center text-muted py-6">Aucun événement trouvé.</td></tr>
      <?php endif; ?>
    </tbody>
  </table>
</div>
<?php if($events->hasPages()): ?>
  <div class="card-footer events-pagination" aria-label="Pagination des événements">
    <?php echo e($events->links('pagination::bootstrap-5')); ?>

  </div>
<?php endif; ?>
<?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/content/admin/events/_results.blade.php ENDPATH**/ ?>