<?php $__env->startSection('title', 'Salle de situation'); ?>

<?php $__env->startSection('vendor-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')('resources/assets/vendor/libs/apex-charts/apex-charts.scss'); ?>
<?php echo app('Illuminate\Foundation\Vite')('resources/assets/css/veille.css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('vendor-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')('resources/assets/vendor/libs/apex-charts/apexcharts.js'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-script'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/js/dashboards-synex.js', 'resources/assets/js/veille-animations.js']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
  $dashboardHeader = $dashboardSections->get('dashboard_header');
?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-4 mb-6">
  <div>
    <?php if($dashboardHeader?->is_active): ?>
      <h4 class="mb-1" data-veille-animation="fade-up"><?php echo e($dashboardHeader->title); ?></h4>
      <?php if($dashboardHeader->description): ?><p class="text-muted mb-0" data-veille-animation="fade-up"><?php echo e($dashboardHeader->description); ?></p><?php endif; ?>
    <?php endif; ?>
  </div>
  <div class="d-flex flex-wrap gap-2">
    <?php if(auth()->user()?->isAdmin()): ?>
      <a href="<?php echo e(route('admin.veille.index')); ?>" class="btn btn-outline-primary"><i class="icon-base bx bx-slider-alt me-1"></i>Gérer le contenu</a>
    <?php endif; ?>
    <a href="<?php echo e(route('dashboard-analytics-base')); ?>" class="btn btn-outline-secondary"><i class="icon-base bx bx-copy me-1"></i>Vue analytique de base</a>
  </div>
</div>

<div class="alert alert-info d-flex align-items-start gap-2 mb-6" role="status">
  <i class="icon-base bx bx-info-circle mt-1"></i>
  <div>
    <strong>Données du fichier fourni</strong>
    <span class="d-block">Les graphiques portent sur les événements importés. Les champs d’impact vides ne sont pas comptés comme des valeurs renseignées.</span>
  </div>
</div>

<form method="GET" action="<?php echo e(route('dashboard-analytics')); ?>" class="card mb-6">
  <div class="card-body">
    <div class="row g-4 align-items-end">
      <div class="col-sm-6 col-xl-2">
        <label for="filter-year" class="form-label">Année</label>
        <select id="filter-year" name="year" class="form-select">
          <option value="">Toutes</option>
          <?php $__currentLoopData = $years; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $year): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($year); ?>" <?php if(($filters['year'] ?? '') == $year): echo 'selected'; endif; ?>><?php echo e($year); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-sm-6 col-xl-2">
        <label for="filter-province" class="form-label">Province</label>
        <select id="filter-province" name="province" class="form-select">
          <option value="">Toutes</option>
          <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($province); ?>" <?php if(($filters['province'] ?? '') === $province): echo 'selected'; endif; ?>><?php echo e($province); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-sm-6 col-xl-2">
        <label for="filter-event-type" class="form-label">Type d’événement</label>
        <select id="filter-event-type" name="event_type_id" class="form-select">
          <option value="">Tous</option>
          <?php $__currentLoopData = $eventTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $eventType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($eventType->id); ?>" <?php if(($filters['event_type_id'] ?? '') == $eventType->id): echo 'selected'; endif; ?>><?php echo e($eventType->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-sm-6 col-xl-2">
        <label for="filter-sub-event" class="form-label">Sous-événement</label>
        <select id="filter-sub-event" name="sub_event_id" class="form-select">
          <option value="">Tous</option>
          <?php $__currentLoopData = $subEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subEvent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($subEvent->id); ?>" <?php if(($filters['sub_event_id'] ?? '') == $subEvent->id): echo 'selected'; endif; ?>>
              <?php echo e($subEvent->name); ?><?php echo e($subEvent->eventType ? ' — '.$subEvent->eventType->name : ''); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-sm-6 col-xl-2">
        <label for="filter-other-event" class="form-label">Autre</label>
        <select id="filter-other-event" name="other_event_id" class="form-select">
          <option value="">Tous</option>
          <?php $__currentLoopData = $otherEvents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $otherEvent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($otherEvent->id); ?>" <?php if(($filters['other_event_id'] ?? '') == $otherEvent->id): echo 'selected'; endif; ?>><?php echo e($otherEvent->description); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-sm-6 col-xl-2">
        <label for="filter-theme" class="form-label">Thématique</label>
        <select id="filter-theme" name="theme_id" class="form-select">
          <option value="">Toutes</option>
          <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($theme->id); ?>" <?php if(($filters['theme_id'] ?? '') == $theme->id): echo 'selected'; endif; ?>><?php echo e($theme->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-sm-6 col-xl-2">
        <label for="filter-subtheme" class="form-label">Sous-thématique</label>
        <select id="filter-subtheme" name="subtheme_id" class="form-select">
          <option value="">Toutes</option>
          <?php $__currentLoopData = $subthemes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subtheme): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($subtheme->id); ?>" <?php if(($filters['subtheme_id'] ?? '') == $subtheme->id): echo 'selected'; endif; ?>>
              <?php echo e($subtheme->name); ?><?php echo e($subtheme->theme ? ' — '.$subtheme->theme->name : ''); ?>

            </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-sm-6 col-xl-2">
        <label for="filter-actor" class="form-label">Acteur</label>
        <select id="filter-actor" name="actor_id" class="form-select">
          <option value="">Tous</option>
          <?php $__currentLoopData = $actors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($actor->id); ?>" <?php if(($filters['actor_id'] ?? '') == $actor->id): echo 'selected'; endif; ?>><?php echo e($actor->name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-sm-6 col-xl-3">
        <label for="filter-search" class="form-label">Recherche</label>
        <input id="filter-search" type="search" name="search" value="<?php echo e($filters['search'] ?? ''); ?>" class="form-control" placeholder="Lieu, type, acteur, note…">
      </div>
      <div class="col-12 d-flex flex-wrap gap-2">
        <button type="submit" class="btn btn-primary">
          <i class="icon-base bx bx-filter-alt me-1"></i>
          Appliquer les filtres
        </button>
        <a href="<?php echo e(route('dashboard-analytics')); ?>" class="btn btn-outline-secondary">Réinitialiser</a>
      </div>
    </div>
  </div>
</form>

<?php
  $metricSection = $dashboardSections->get('dashboard_metrics');
?>
<?php if($metricSection?->is_active): ?>
  <div class="mb-6">
    <?php if($metricSection->title): ?><h5 class="mb-1"><?php echo e($metricSection->title); ?></h5><?php endif; ?>
    <?php if($metricSection->description): ?><p class="text-muted mb-4"><?php echo e($metricSection->description); ?></p><?php endif; ?>
    <div class="row g-6">
      <?php
        $metricColumn = max(3, (int) floor(12 / max(1, $metricSection->cards->count())));
      ?>
      <?php $__currentLoopData = $metricSection->cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-sm-6 col-xl-<?php echo e($metricColumn); ?>">
          <article class="card h-100 veille-content-card" data-veille-animation="<?php echo e($card->animation); ?>">
            <div class="card-body">
              <div class="d-flex justify-content-between align-items-start">
                <div>
                  <span class="text-muted"><?php echo e($card->title); ?></span>
                  <h3 class="mb-0 mt-2"><?php echo e(number_format($metricValues[$card->component_key] ?? 0, 0, ',', ' ')); ?></h3>
                  <?php if($card->description): ?><small class="text-muted d-block mt-2"><?php echo e($card->description); ?></small><?php endif; ?>
                </div>
                <?php if($card->icon): ?><span class="avatar-initial rounded bg-label-<?php echo e($card->color); ?> p-2"><i class="icon-base bx <?php echo e($card->icon); ?> icon-lg"></i></span><?php endif; ?>
              </div>
            </div>
          </article>
        </div>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </div>
<?php endif; ?>

<?php
  $chartSection = $dashboardSections->get('dashboard_charts');
?>
<?php if($chartSection?->is_active && $chartSection->cards->isNotEmpty()): ?>
  <section class="mb-6">
    <div class="mb-4">
      <?php if($chartSection->title): ?><h5 class="mb-1"><?php echo e($chartSection->title); ?></h5><?php endif; ?>
      <?php if($chartSection->description): ?><p class="text-muted mb-0"><?php echo e($chartSection->description); ?></p><?php endif; ?>
    </div>
    <div class="row g-6">
      <?php $__currentLoopData = $chartSection->cards; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php
          $chartIds = [
              'eventsByYear' => ['eventsByYearChart', 'col-12 col-xl-8'],
              'eventsByProvince' => ['eventsByProvinceChart', 'col-12 col-xl-4'],
              'eventsByType' => ['eventsByTypeChart', 'col-12 col-xl-6'],
              'eventsByTheme' => ['eventsByThemeChart', 'col-12 col-xl-6'],
              'impacts' => ['recordedImpactsChart', 'col-12'],
              'death_rate' => ['deathsPer100kChart', 'col-12'],
          ];
          $chartConfig = $chartIds[$card->component_key] ?? null;
        ?>
        <?php if($chartConfig): ?>
          <div class="<?php echo e($chartConfig[1]); ?>">
            <article class="card h-100 veille-content-card" data-veille-animation="<?php echo e($card->animation); ?>">
              <div class="card-header">
                <h6 class="card-title mb-1"><?php echo e($card->title); ?></h6>
                <?php if($card->description): ?><p class="card-subtitle mb-0"><?php echo e($card->description); ?></p><?php endif; ?>
                <?php if($card->component_key === 'death_rate' && $deathRateYear): ?><small class="text-muted">Année <?php echo e($deathRateYear); ?></small><?php endif; ?>
              </div>
              <div class="card-body">
                <div id="<?php echo e($chartConfig[0]); ?>" aria-label="<?php echo e($card->title); ?>"></div>
                <?php if($card->component_key === 'death_rate' && $deathRates->isEmpty()): ?>
                  <p class="text-muted mb-0">Saisissez les populations par province et par année dans la gestion de la veille pour calculer ce taux.</p>
                <?php endif; ?>
              </div>
            </article>
          </div>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
  </section>
<?php endif; ?>

<?php
  $mapSection = $dashboardSections->get('dashboard_map');
?>
<?php if($mapSection?->is_active): ?>
  <div class="card mb-6 veille-content-card" data-veille-animation="fade-up">
    <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-2">
      <div>
        <h5 class="card-title mb-1"><?php echo e($mapSection->title); ?></h5>
        <?php if($mapSection->description): ?><p class="card-subtitle mb-0"><?php echo e($mapSection->description); ?></p><?php endif; ?>
      </div>
      <span class="badge bg-label-primary"><?php echo e(number_format(count($mapPoints), 0, ',', ' ')); ?> points</span>
    </div>
    <div class="card-body pt-0">
      <div id="synexEventsMap" role="application" aria-label="<?php echo e($mapSection->title); ?>" style="height: 460px; min-height: 320px;"></div>
    </div>
  </div>
<?php endif; ?>

<script>
  window.synexDashboardCharts = <?php echo \Illuminate\Support\Js::from($chartData)->toHtml() ?>;
  window.synexMapPoints = <?php echo \Illuminate\Support\Js::from($mapPoints)->toHtml() ?>;
  window.synexDeathRateYear = <?php echo \Illuminate\Support\Js::from($deathRateYear)->toHtml() ?>;
</script>

<?php
  $journalSection = $dashboardSections->get('dashboard_journal');
?>
<?php if($journalSection?->is_active): ?>
<div class="card">
  <div class="card-header d-flex flex-wrap justify-content-between align-items-center gap-3">
    <div>
      <h5 class="card-title mb-1"><?php echo e($journalSection->title); ?></h5>
      <?php if($journalSection->description): ?><p class="card-subtitle mb-1"><?php echo e($journalSection->description); ?></p><?php endif; ?>
      <p class="card-subtitle mb-0">
        <?php if($events->total()): ?>
          <?php echo e(number_format($events->firstItem(), 0, ',', ' ')); ?>–<?php echo e(number_format($events->lastItem(), 0, ',', ' ')); ?>

          sur <?php echo e(number_format($events->total(), 0, ',', ' ')); ?> événements
        <?php else: ?>
          Aucun événement ne correspond à ces filtres.
        <?php endif; ?>
      </p>
    </div>
  </div>
  <div class="table-responsive">
    <table class="table table-hover align-middle mb-0">
      <thead>
        <tr>
          <th>Date</th>
          <th>Événement</th>
          <th>Thématique</th>
          <th>Province / localité</th>
          <th>Acteurs</th>
          <th>Impacts</th>
          <th>Source</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $events; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $event): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td class="text-nowrap"><?php echo e($event->event_date_raw ?: '—'); ?></td>
            <td>
              <span class="fw-medium"><?php echo e($event->eventTypeRecord?->name ?: '—'); ?></span>
              <?php if($event->subEventRecord): ?>
                <small class="d-block text-muted"><?php echo e($event->subEventRecord->name); ?></small>
              <?php endif; ?>
              <?php if($event->otherEventRecord): ?>
                <small class="d-block text-muted"><?php echo e($event->otherEventRecord->description); ?></small>
              <?php endif; ?>
            </td>
            <td>
              <span><?php echo e($event->themeRecord?->name ?: '—'); ?></span>
              <?php if($event->subthemeRecord): ?>
                <small class="d-block text-muted"><?php echo e($event->subthemeRecord->name); ?></small>
              <?php endif; ?>
            </td>
            <td>
              <span class="fw-medium"><?php echo e($event->province ?: '—'); ?></span>
              <?php if($event->locality): ?>
                <small class="d-block text-muted"><?php echo e($event->locality); ?></small>
              <?php endif; ?>
            </td>
            <td><?php echo e($event->actors->pluck('name')->join(' ↔ ') ?: '—'); ?></td>
            <td class="text-nowrap">
              <span class="text-danger"><?php echo e($event->deaths ?? 0); ?> décès</span>
              <small class="d-block text-muted"><?php echo e($event->injuries ?? 0); ?> blessés</small>
            </td>
            <td>
              <?php if($event->source_url_1 && in_array(parse_url($event->source_url_1, PHP_URL_SCHEME), ['http', 'https'], true)): ?>
                <a href="<?php echo e($event->source_url_1); ?>" target="_blank" rel="noopener noreferrer"><?php echo e($event->source ?: 'Consulter'); ?></a>
              <?php else: ?>
                <?php echo e($event->source ?: '—'); ?>

              <?php endif; ?>
              <?php if($event->event_notes): ?>
                <small class="d-block text-muted"><?php echo e(\Illuminate\Support\Str::limit($event->event_notes, 90)); ?></small>
              <?php endif; ?>
            </td>
          </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="7" class="text-center py-8 text-muted">Aucun événement à afficher.</td>
          </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>
  <?php if($events->hasPages()): ?>
    <div class="card-footer">
      <?php echo e($events->links('pagination::bootstrap-5')); ?>

    </div>
  <?php endif; ?>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/content/dashboard/dashboards-synex.blade.php ENDPATH**/ ?>