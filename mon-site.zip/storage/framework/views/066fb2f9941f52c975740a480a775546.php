<?php ($editing = $news->exists); ?>

<?php $__env->startSection('html-lang', 'fr'); ?>
<?php $__env->startSection('title', $editing ? 'Modifier une actualité' : 'Nouvelle actualité'); ?>

<?php $__env->startSection('content'); ?>
<div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-6">
  <div>
    <h4 class="mb-1"><?php echo e($editing ? 'Modifier une actualité' : 'Nouvelle actualité'); ?></h4>
    <p class="text-muted mb-0">Renseignez le contenu et l’image qui seront présentés dans les cartes Sneat.</p>
  </div>
  <a href="<?php echo e(route('admin.program-news.index')); ?>" class="btn btn-outline-secondary">Retour à la liste</a>
</div>

<?php if($errors->any()): ?>
  <div class="alert alert-danger" role="alert">
    <ul class="mb-0"><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul>
  </div>
<?php endif; ?>

<form method="POST" action="<?php echo e($editing ? route('admin.program-news.update', $news) : route('admin.program-news.store')); ?>" enctype="multipart/form-data">
  <?php echo csrf_field(); ?>
  <?php if($editing): ?>
    <?php echo method_field('PUT'); ?>
  <?php endif; ?>
  <div class="card mb-6">
    <div class="card-header"><h5 class="card-title mb-0">Contenu de l’actualité</h5></div>
    <div class="card-body row g-4">
      <div class="col-12">
        <label for="news-title" class="form-label">Titre *</label>
        <input id="news-title" name="title" class="form-control" maxlength="180" value="<?php echo e(old('title', $news->title)); ?>" required>
      </div>
      <div class="col-12">
        <label for="news-summary" class="form-label">Courte description *</label>
        <textarea id="news-summary" name="summary" rows="2" class="form-control" maxlength="500" required><?php echo e(old('summary', $news->summary)); ?></textarea>
        <div class="form-text">500 caractères maximum.</div>
      </div>
      <div class="col-md-6">
        <label for="news-category" class="form-label">Catégorie *</label>
        <select id="news-category" name="category" class="form-select" required>
          <option value="">Choisir une catégorie</option>
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php if(old('category', $news->category) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-md-6">
        <label for="news-region" class="form-label">Région *</label>
        <select id="news-region" name="region" class="form-select" required>
          <option value="">Choisir une région</option>
          <?php $__currentLoopData = $regions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($value); ?>" <?php if(old('region', $news->region) === $value): echo 'selected'; endif; ?>><?php echo e($label); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
      </div>
      <div class="col-12">
        <label for="news-content" class="form-label">Article complet *</label>
        <textarea id="news-content" name="content" rows="10" class="form-control" maxlength="50000" required><?php echo e(old('content', $news->content)); ?></textarea>
      </div>
      <div class="col-md-6">
        <label for="news-image" class="form-label">Image <?php echo e($editing ? '(facultative)' : '*'); ?></label>
        <input id="news-image" name="image" type="file" accept=".jpg,.jpeg,.png,.webp" class="form-control" <?php if(!$editing): echo 'required'; endif; ?>>
        <div class="form-text">JPG, PNG ou WEBP, 5 Mo maximum.</div>
        <?php if($editing && $news->image_path): ?>
          <img src="<?php echo e(asset('storage/'.$news->image_path)); ?>" alt="Image actuelle de <?php echo e($news->title); ?>" class="img-thumbnail mt-3" style="max-height: 180px">
        <?php endif; ?>
      </div>
      <div class="col-md-6">
        <label for="published-at" class="form-label">Date de publication *</label>
        <input id="published-at" name="published_at" type="datetime-local" class="form-control" value="<?php echo e(old('published_at', $news->published_at?->format('Y-m-d\TH:i'))); ?>" required>
        <div class="form-text">Une actualité programmée apparaîtra à cette date si elle est publiée.</div>
      </div>
      <div class="col-12">
        <div class="form-check">
          <input id="news-published" name="is_published" type="checkbox" class="form-check-input" value="1" <?php if(old('is_published', $news->is_published)): echo 'checked'; endif; ?>>
          <label for="news-published" class="form-check-label">Publier cette actualité</label>
        </div>
      </div>
    </div>
  </div>
  <div class="d-flex justify-content-end gap-2">
    <a href="<?php echo e(route('admin.program-news.index')); ?>" class="btn btn-label-secondary">Annuler</a>
    <button type="submit" class="btn btn-primary">
      <i class="icon-base bx bx-save me-1"></i><?php echo e($editing ? 'Enregistrer les modifications' : 'Créer l’actualité'); ?>

    </button>
  </div>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/contentNavbarLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/content/admin/program-news/form.blade.php ENDPATH**/ ?>