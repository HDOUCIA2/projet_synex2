<?php
$width = $width ?? 32;
$variant = $variant ?? 'dore';
?>

<span class="text-primary d-inline-flex align-items-center">
    <?php if($siteSettings?->logo_path): ?>
        <img src="<?php echo e(asset('storage/'.$siteSettings->logo_path)); ?>" alt="" style="max-width: <?php echo e($width); ?>px; max-height: <?php echo e($width); ?>px; object-fit: contain">
    <?php else: ?>
        <img src="<?php echo e(asset('assets/img/branding/svg/symbole_'.$variant.'.svg')); ?>" alt="" width="<?php echo e($width); ?>" height="<?php echo e($width); ?>">
    <?php endif; ?>
</span>
<?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/_partials/macros.blade.php ENDPATH**/ ?>