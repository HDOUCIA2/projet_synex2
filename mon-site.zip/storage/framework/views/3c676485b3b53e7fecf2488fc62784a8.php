<?php $__env->startSection('html-lang', 'fr'); ?>
<?php $__env->startSection('title', 'Créer un profil'); ?>

<?php $__env->startSection('page-style'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/assets/vendor/scss/pages/page-auth.scss']); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-xxl">
    <div class="authentication-wrapper authentication-basic container-p-y">
        <div class="authentication-inner">
            <div class="card px-sm-6 px-0">
                <div class="card-body">
                    <div class="app-brand justify-content-center mb-6">
                        <a href="<?php echo e(url('/')); ?>" class="app-brand-link gap-2">
                            <span class="app-brand-logo demo"><?php echo $__env->make('_partials.macros', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>
                            <span class="app-brand-text demo text-heading fw-bold"><?php echo e($siteSettings->name); ?></span>
                        </a>
                    </div>

                    <h4 class="mb-1">Créer un profil <?php echo e($siteSettings->name); ?></h4>
                    <p class="mb-6">Inscrivez-vous pour accéder au tableau de bord comme utilisateur simple.</p>

                    <?php if($errors->any()): ?>
                    <div class="alert alert-danger" role="alert">
                        <ul class="mb-0">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                    <?php endif; ?>

                    <form id="formAuthentication" class="mb-6" action="<?php echo e(route('auth.register')); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="mb-6">
                            <label for="name" class="form-label">Nom complet</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>" autocomplete="name" required autofocus />
                        </div>
                        <div class="mb-6">
                            <label for="username" class="form-label">Identifiant</label>
                            <input type="text" class="form-control" id="username" name="username" value="<?php echo e(old('username')); ?>" autocomplete="username" required />
                        </div>
                        <div class="mb-6">
                            <label for="email" class="form-label">Adresse e-mail</label>
                            <input type="email" class="form-control" id="email" name="email" value="<?php echo e(old('email')); ?>" autocomplete="email" required />
                        </div>
                        <div class="mb-6 form-password-toggle">
                            <label class="form-label" for="password">Mot de passe</label>
                            <div class="input-group input-group-merge">
                                <input type="password" id="password" class="form-control" name="password" autocomplete="new-password" minlength="12" required />
                                <span class="input-group-text cursor-pointer"><i class="icon-base bx bx-hide"></i></span>
                            </div>
                            <div class="form-text">12 caractères minimum.</div>
                        </div>
                        <div class="mb-6">
                            <label class="form-label" for="password_confirmation">Confirmer le mot de passe</label>
                            <input type="password" id="password_confirmation" class="form-control" name="password_confirmation" autocomplete="new-password" minlength="12" required />
                        </div>
                        <button class="btn btn-primary d-grid w-100" type="submit">Créer mon profil</button>
                    </form>

                    <p class="text-center mb-0">
                        Vous avez déjà un compte ?
                        <a href="<?php echo e(route('auth-login-basic')); ?>">Se connecter</a>
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/blankLayout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/content/authentications/auth-register-basic.blade.php ENDPATH**/ ?>