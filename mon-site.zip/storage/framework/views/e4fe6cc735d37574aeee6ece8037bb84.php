<?php ($activePage = $activePage ?? ''); ?>

<nav class="navbar navbar-expand-xl navbar-light bg-white shadow-sm sticky-top synex-navbar" aria-label="Navigation principale">
  <div class="container-fluid px-4">
    <a class="navbar-brand d-flex align-items-center gap-2 me-4" href="<?php echo e(route('home')); ?>">
      <span class="d-inline-flex" aria-hidden="true"><?php echo $__env->make('_partials.macros', ['width' => 35, 'variant' => 'dore'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></span>
      <span class="fw-bold text-dark fs-4"><?php echo e($siteSettings->name); ?></span>
      <span class="text-muted small border-start ps-3 ms-2 d-none d-xxl-inline">Suivi &amp; Analyse des Conflits</span>
    </a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#synexNavbar" aria-controls="synexNavbar" aria-expanded="false" aria-label="Ouvrir le menu">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="synexNavbar">
      <ul class="navbar-nav mx-auto align-items-xl-center gap-xl-2">
        <li class="nav-item">
          <a class="nav-link <?php echo e($activePage === 'home' ? 'active' : ''); ?>" href="<?php echo e(route('home')); ?>" <?php if($activePage === 'home'): ?> aria-current="page" <?php endif; ?>>Accueil</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle <?php echo e($activePage === 'analyses' ? 'active' : ''); ?>" href="<?php echo e(route('dashboard-analytics')); ?>" role="button" data-bs-toggle="dropdown" aria-expanded="false">Analyses</a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="<?php echo e(route('dashboard-analytics')); ?>">Analyses des conflits</a></li>
            <li><a class="dropdown-item" href="<?php echo e(route('dashboard-analytics')); ?>#synexEventsMap">Analyses territoriales</a></li>
          </ul>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e($activePage === 'veille' ? 'active' : ''); ?>" href="<?php echo e(route('veille')); ?>" <?php if($activePage === 'veille'): ?> aria-current="page" <?php endif; ?>>Veille</a>
        </li>
        <li class="nav-item">
          <a class="nav-link <?php echo e($activePage === 'program-news' ? 'active' : ''); ?>" href="<?php echo e(route('program-news.index')); ?>" <?php if($activePage === 'program-news'): ?> aria-current="page" <?php endif; ?>>Actualités du programme</a>
        </li>
      </ul>
      <div class="d-flex align-items-center gap-2 mt-3 mt-xl-0">
        <a href="<?php echo e(route('dashboard-analytics')); ?>" class="btn btn-primary d-flex align-items-center gap-2 px-3">
          <i class="icon-base bx bx-grid-alt" aria-hidden="true"></i>
          <span>Tableau de bord</span>
        </a>
        <?php if(auth()->guard()->guest()): ?>
          <a href="<?php echo e(route('auth-login-basic')); ?>" class="btn btn-outline-primary d-flex align-items-center gap-2 px-3">
            <i class="icon-base bx bx-user" aria-hidden="true"></i>
            <span>Connexion</span>
          </a>
        <?php else: ?>
          <a href="<?php echo e(route('pages-account-settings-account')); ?>" class="btn btn-outline-primary d-flex align-items-center gap-2 px-3">
            <i class="icon-base bx bx-user" aria-hidden="true"></i>
            <span>Mon profil</span>
          </a>
        <?php endif; ?>
      </div>
    </div>
  </div>
</nav>
<?php /**PATH /workspaces/sneat-bootstrap-html-laravel-admin-template-free/resources/views/content/pages/_public-navbar.blade.php ENDPATH**/ ?>