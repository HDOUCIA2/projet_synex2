@extends('layouts/blankLayout')

@section('html-lang', 'fr')
@section('title', $news->title.' — Actualités du programme')

@section('content')
@include('content.pages._public-navbar', ['activePage' => 'program-news'])

<main class="container-xxl px-4 py-5">
  <nav aria-label="Fil d’Ariane" class="mb-4">
    <ol class="breadcrumb mb-0">
      <li class="breadcrumb-item"><a href="{{ route('home') }}">Accueil</a></li>
      <li class="breadcrumb-item"><a href="{{ route('program-news.index') }}">Actualités du programme</a></li>
      <li class="breadcrumb-item active" aria-current="page">{{ $news->title }}</li>
    </ol>
  </nav>

  <article class="card">
    <img class="card-img-top object-fit-cover" src="{{ asset('storage/'.$news->image_path) }}" alt="{{ $news->title }}" style="max-height: 480px">
    <div class="card-body p-4 p-md-5">
      <p class="card-text text-muted mb-2">
        <i class="icon-base bx bx-calendar me-1" aria-hidden="true"></i>{{ $news->published_at->format('d/m/Y') }}
      </p>
      @if ($news->category || $news->region)
        <div class="d-flex flex-wrap gap-2 mb-3">
          @if ($news->category)
            <span class="badge bg-label-primary">{{ \App\Models\ProgramNews::CATEGORIES[$news->category] ?? $news->category }}</span>
          @endif
          @if ($news->region)
            <span class="badge bg-label-secondary">{{ \App\Models\ProgramNews::REGIONS[$news->region] ?? $news->region }}</span>
          @endif
        </div>
      @endif
      <h1 class="card-title mb-3">{{ $news->title }}</h1>
      <p class="lead">{{ $news->summary }}</p>
      <div class="card-text">{!! nl2br(e($news->content)) !!}</div>
      <a href="{{ route('program-news.index') }}" class="btn btn-outline-primary mt-4">
        <i class="icon-base bx bx-arrow-back me-1" aria-hidden="true"></i>Retour aux actualités
      </a>
    </div>
  </article>
</main>
@endsection
